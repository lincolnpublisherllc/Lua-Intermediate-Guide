function Trie.new()
  return setmetatable({ children = {}, terminal = false }, Trie)
end

function Trie:insert(word)
  local node = self
  for i = 1, #word do
    local ch = word:sub(i,i)
    node.children[ch] = node.children[ch] or Trie.new()
    node = node.children[ch]
  end
  node.terminal = true
end

local function collect(node, prefix, out)
  if node.terminal then table.insert(out, prefix) end
  for ch, child in pairs(node.children) do
    collect(child, prefix .. ch, out)
  end
end

function Trie:prefix_search(prefix)
  local node = self
  for i = 1, #prefix do
    node = node.children[prefix:sub(i,i)]
    if not node then return {} end
  end
  local out = {}
  collect(node, prefix, out)
  table.sort(out)
  return out
end

return Trie