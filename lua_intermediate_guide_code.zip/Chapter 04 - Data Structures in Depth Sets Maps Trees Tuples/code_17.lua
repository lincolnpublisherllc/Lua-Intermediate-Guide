-- tuple.lua
local function Tuple(keys)
  local idx = {}
  for i, k in ipairs(keys) do idx[k] = i end

  local mt = {
    __index = function(t, k)
      local i = idx[k]; if i then return rawget(t, i) end
    end,
    __newindex = function() error("tuple is immutable") end,
    __tostring = function(t)
      local parts = {}
      for i, k in ipairs(keys) do parts[i] = k .. "=" .. tostring(t[i]) end
      return "<"..table.concat(parts, ", ")..">"
    end,
  }

  local function new(...)
    local t = {...}
    if #t ~= #keys then error("tuple arity "..#keys) end
    return setmetatable(t, mt)
  end

  return { new = new, keys = keys }
end

return Tuple