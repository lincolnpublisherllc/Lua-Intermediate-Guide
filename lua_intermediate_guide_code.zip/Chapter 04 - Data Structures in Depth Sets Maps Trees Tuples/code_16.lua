print(q:pop()) -- high  1
print(q:pop()) -- mid   5
print(q:pop()) -- low   10