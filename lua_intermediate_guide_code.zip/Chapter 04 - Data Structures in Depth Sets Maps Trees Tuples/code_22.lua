function Scheduler.new(now)
  return setmetatable({ now = now or 0, q = PQ.new(function(a,b) return a < b end) }, Scheduler)
end

function Scheduler:schedule(delay, f, id)
  local run_at = self.now + delay
  self.q:push({ id = id or ("t"..tostring(math.random(1e6))), f = f, run_at = run_at }, run_at)
end

function Scheduler:advance(dt)
  self.now = self.now + dt
  while true do
    local top, prio = self.q:peek()
    if not top or prio > self.now then break end
    self.q:pop()
    local ok, err = pcall(top.f, self, top)
    if not ok then
      io.write(string.format("[%.2f] task %s error: %s\n", self.now, top.id, err))
    end
  end
end

function Scheduler:run_until(t)
  if t < self.now then return end
  self:advance(t - self.now)
end

return Scheduler