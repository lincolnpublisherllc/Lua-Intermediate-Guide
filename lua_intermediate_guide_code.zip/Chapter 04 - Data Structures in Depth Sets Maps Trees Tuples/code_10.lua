-- bst.lua
local function node(key, val) return {k=key, v=val, left=nil, right=nil} end

local BST = {}