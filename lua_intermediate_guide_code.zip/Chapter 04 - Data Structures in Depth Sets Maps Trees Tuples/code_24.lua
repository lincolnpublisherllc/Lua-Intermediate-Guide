function Set.union(a,b)
  local s = Set.new(a:values())
  for _, v in ipairs(b:values()) do s:add(v) end
  return s
end
function Set.intersect(a,b)
  local s = Set.new()
  for _, v in ipairs(a:values()) do if b:has(v) then s:add(v) end end
  return s
end
function Set.diff(a,b)
  local s = Set.new()
  for _, v in ipairs(a:values()) do if not b:has(v) then s:add(v) end end
  return s
end