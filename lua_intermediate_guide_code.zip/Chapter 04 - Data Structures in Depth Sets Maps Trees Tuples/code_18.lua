local Tuple = require("tuple")
local User = Tuple({"id","name","active"})
local u = User.new(101, "Ada", true)
print(u.name, u[2], tostring(u)) -- Ada  Ada  <id=101, name=Ada, active=true>
-- u.name = "Zara" -- error: immutable