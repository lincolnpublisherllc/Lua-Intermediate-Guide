local memo = require("memo").memoize
local function slow(x) -- pretend heavy calc
  local s = 0; for i=1,1e5 do s = s + (x%7) end; return s
end
local fast = memo(slow)
print(fast(9)); print(fast(9)) -- second call hits cache