-- trie.lua
local Trie = {}