local Trie = require("trie")
local t = Trie.new()
for _, w in ipairs({"car","cart","cat","dog"}) do t:insert(w) end
print(table.concat(t:prefix_search("ca"), ", ")) -- car, cart, cat