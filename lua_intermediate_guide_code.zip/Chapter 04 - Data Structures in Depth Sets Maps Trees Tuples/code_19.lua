-- memo.lua
local function memoize(f)
  local cache = setmetatable({}, { __mode = "kv" }) -- weak keys and values
  return function(x)
    local v = cache[x]
    if v == nil then
      v = f(x)
      cache[x] = v
    end
    return v
  end
end

return { memoize = memoize }