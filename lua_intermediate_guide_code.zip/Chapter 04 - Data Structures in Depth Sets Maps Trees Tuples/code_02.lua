function Set.new(list)
  local self = setmetatable({ _ = {} }, Set)
  if list then
    for _, v in ipairs(list) do self._[v] = true end
  end
  return self
end

function Set:has(x) return self._[x] == true end
function Set:add(x) self._[x] = true end
function Set:del(x) self._[x] = nil end

function Set:values() -- iteration as ipairs-friendly array
  local out, i = {}, 1
  for k in pairs(self._) do out[i], i = k, i + 1 end
  table.sort(out) -- optional: stable order for printing/tests
  return out
end

return Set