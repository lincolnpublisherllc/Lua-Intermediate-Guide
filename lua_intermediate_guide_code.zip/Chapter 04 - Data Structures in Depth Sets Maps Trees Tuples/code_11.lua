function BST.new() return setmetatable({ root=nil }, BST) end

local function insert(n, key, val)
  if not n then return node(key, val) end
  if key < n.k then n.left = insert(n.left, key, val)
  elseif key > n.k then n.right = insert(n.right, key, val)
  else n.v = val end
  return n
end

function BST:set(key, val) self.root = insert(self.root, key, val) end

local function find(n, key)
  if not n then return nil end
  if key < n.k then return find(n.left, key)
  elseif key > n.k then return find(n.right, key)
  else return n.v end
end

function BST:get(key) return find(self.root, key) end

function BST:iter()
  local stack, cur = {}, self.root
  return function()
    while cur do table.insert(stack, cur); cur = cur.left end
    cur = table.remove(stack)
    if not cur then return end
    local k, v = cur.k, cur.v
    cur = cur.right
    return k, v
  end
end

return BST