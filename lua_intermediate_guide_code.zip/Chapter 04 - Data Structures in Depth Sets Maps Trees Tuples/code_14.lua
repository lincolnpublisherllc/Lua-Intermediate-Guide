function PQueue.new(cmp)
  return setmetatable({ a = {}, n = 0, cmp = cmp or function(x,y) return x < y end }, PQueue)
end

local function parent(i) return math.floor(i/2) end
local function left(i) return 2*i end
local function right(i) return 2*i+1 end

local function swap(A, i, j) A[i], A[j] = A[j], A[i] end

function PQueue:push(item, prio)
  self.n = self.n + 1
  local i = self.n
  self.a[i] = {item=item, prio=prio}
  while i > 1 and self.cmp(self.a[i].prio, self.a[parent(i)].prio) do
    swap(self.a, i, parent(i))
    i = parent(i)
  end
end

function PQueue:peek()
  if self.n == 0 then return nil end
  return self.a[1].item, self.a[1].prio
end

function PQueue:pop()
  if self.n == 0 then return nil end
  local top = self.a[1]
  self.a[1] = self.a[self.n]
  self.a[self.n] = nil
  self.n = self.n - 1

  local i = 1
  while true do
    local l, r = left(i), right(i)
    local smallest = i
    if l <= self.n and self.cmp(self.a[l].prio, self.a[smallest].prio) then smallest = l end
    if r <= self.n and self.cmp(self.a[r].prio, self.a[smallest].prio) then smallest = r end
    if smallest == i then break end
    swap(self.a, i, smallest)
    i = smallest
  end

  return top.item, top.prio
end

function PQueue:size() return self.n end

return PQueue