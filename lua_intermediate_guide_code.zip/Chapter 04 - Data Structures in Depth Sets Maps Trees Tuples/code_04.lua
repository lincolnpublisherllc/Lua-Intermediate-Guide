-- ordered_map.lua
local OrderedMap = {}