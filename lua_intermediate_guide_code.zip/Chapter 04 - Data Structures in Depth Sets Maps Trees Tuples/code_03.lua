local Set = require("set")
local s = Set.new({"red","blue"})