local BST = require("bst")
local t = BST.new()