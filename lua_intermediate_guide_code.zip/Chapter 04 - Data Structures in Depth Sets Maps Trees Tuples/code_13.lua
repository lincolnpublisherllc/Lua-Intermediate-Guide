-- pqueue.lua
local PQueue = {}