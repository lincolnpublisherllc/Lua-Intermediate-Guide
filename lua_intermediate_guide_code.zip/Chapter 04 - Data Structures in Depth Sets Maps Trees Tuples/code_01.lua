-- set.lua
local Set = {}