function OrderedMap.new()
  return setmetatable({ _dict = {}, _keys = {} }, OrderedMap)
end

local function index_of(t, key)
  for i, k in ipairs(t._keys) do if k == key then return i end end
  return nil
end

function OrderedMap:set(key, value)
  if tostring(key) == nil then return nil, "bad_key" end
  if self._dict[key] == nil then table.insert(self._keys, key) end
  self._dict[key] = value
  return true
end

function OrderedMap:get(key) return self._dict[key] end

function OrderedMap:del(key)
  if self._dict[key] == nil then return false end
  self._dict[key] = nil
  local i = index_of(self, key)
  if i then table.remove(self._keys, i) end
  return true
end

function OrderedMap:iter()
  local i = 0
  return function()
    i = i + 1
    local k = self._keys[i]
    if k then return k, self._dict[k] end
  end
end

return OrderedMap