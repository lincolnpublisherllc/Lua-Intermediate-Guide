local DEBUG = os.getenv("APP_DEBUG") == "1"
local function crash(msg)
  if DEBUG then
    return debug.traceback("Fatal: " .. tostring(msg), 2)
  else
    return "Fatal: " .. tostring(msg)
  end
end
local ok, err = xpcall(main, crash)