local function tdiff(a, b, path, acc)
  path, acc = path or "", acc or {}
  local keys = {}
  for k in pairs(a or {}) do keys[k] = true end
  for k in pairs(b or {}) do keys[k] = true end
  for k in pairs(keys) do
    local pa = (path == "" and tostring(k)) or (path .. "." .. tostring(k))
    local va, vb = a and a[k], b and b[k]
    if type(va) == "table" and type(vb) == "table" then
      tdiff(va, vb, pa, acc)
    elseif va ~= vb then
      table.insert(acc, string.format("%s: %s != %s", pa, tostring(va), tostring(vb)))
    end
  end
  return acc
end

-- in a spec:
local diffs = tdiff(actual, expected)