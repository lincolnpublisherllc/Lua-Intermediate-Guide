-- production code
local function stamp(now, fmt)
  now = now or os.time
  fmt = fmt or os.date
  return fmt("%Y-%m-%d %H:%M:%S", now())
end

-- test