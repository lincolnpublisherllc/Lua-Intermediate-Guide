-- src/kvparse/core.lua
local M = {}

local function parse_line(line, n)
  if line:match("^%s*$") or line:match("^%s*#") then return nil end
  local k, v = line:match("^%s*([a-z_][a-z0-9_]*)%s*=%s*([^%s].*)%s*$")
  if not k then
    return nil, string.format("parse_error:%d:bad_syntax", n)
  end
  if v:find("%s") then
    return nil, string.format("parse_error:%d:spaces_in_value", n)
  end
  return k, v
end

function M.parse(text)
  local out = {}
  local n = 0
  for line in (text.."\n"):gmatch("([^\n]*)\n") do
    n = n + 1
    local k, v_or_err = parse_line(line, n)
    if k == nil and v_or_err ~= nil then
      return nil, v_or_err
    elseif k then
      out[k] = v_or_err
    end
  end
  return out
end

return M