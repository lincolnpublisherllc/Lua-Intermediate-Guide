local function traceback(msg)
  return debug.traceback("Fatal: " .. tostring(msg), 2)
end

local function run_safely(f, ...)
  return xpcall(f, traceback, ...)
end

-- entrypoint:
local ok, err = run_safely(function()
  -- main body; may error on contract violations
end)
if not ok then
  io.stderr:write(err, "\n")
  os.exit(1)
end