-- spec/yourlib_spec.lua
local assert = require("luassert")
local yourlib = require("yourlib.core")