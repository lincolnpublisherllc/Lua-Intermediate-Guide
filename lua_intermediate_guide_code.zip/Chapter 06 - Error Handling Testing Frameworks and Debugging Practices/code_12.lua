local writes = {}
local out = { write = function(s) table.insert(writes, s) end }
-- pass `out` into your module; assert on `table.concat(writes)`