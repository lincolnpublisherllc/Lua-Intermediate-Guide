  local fixed = 1_700_000_000
  local s = stamp(function() return fixed end, function(_, t) return "T"..t end)
  assert.are.equal("T1700000000", s)
end)