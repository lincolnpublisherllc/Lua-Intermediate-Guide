local E = {
  bad_input   = "bad_input",
  not_found   = "not_found",
  io_error    = "io_error",
  parse_error = "parse_error",