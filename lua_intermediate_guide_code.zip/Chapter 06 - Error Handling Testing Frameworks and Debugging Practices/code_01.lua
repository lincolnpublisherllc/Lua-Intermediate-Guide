local function expect_string(name, v)
  if type(v) ~= "string" then error(name .. ": string required", 2) end
end

local function read_file(path)
  expect_string("path", path)              -- contract check
  local f, err = io.open(path, "rb")       -- recoverable
  if not f then return nil, "io_open:" .. tostring(err) end
  local data = f:read("*a"); f:close()
  return data
end