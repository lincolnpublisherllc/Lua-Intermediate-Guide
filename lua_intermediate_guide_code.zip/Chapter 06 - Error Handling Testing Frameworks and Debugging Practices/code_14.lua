debug.sethook lets you observe calls/lines/returns. Use rarely and carefully.
local calls = {}
local function hook(event, line)
  if event == "call" then
    local info = debug.getinfo(2, "nS")
    table.insert(calls, (info.short_src or "?") .. ":" .. (info.name or "anon"))
  end
end

local function with_hook(f)
  debug.sethook(hook, "c")  -- call events
  local ok, err = pcall(f)
  debug.sethook()
  return ok, err, calls
end

-- usage
local ok, err, log = with_hook(function()
  -- code under inspection
end)