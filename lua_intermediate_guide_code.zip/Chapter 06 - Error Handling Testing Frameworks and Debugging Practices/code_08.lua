-- spec/golden_spec.lua
local lib = require("fmt")
local function slurp(p) local f=assert(io.open(p,"rb")); local d=f:read("*a"); f:close(); return d end