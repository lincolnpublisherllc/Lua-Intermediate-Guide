-- main.lua
local cli = require("kvparse.cli")
local function top() if not cli.main(arg) then error("failed") end end
local function crash(m) return debug.traceback("Fatal: " .. tostring(m), 2) end
local ok, e = xpcall(top, crash); if not ok then io.stderr:write(e, "\n"); os.exit(1) end