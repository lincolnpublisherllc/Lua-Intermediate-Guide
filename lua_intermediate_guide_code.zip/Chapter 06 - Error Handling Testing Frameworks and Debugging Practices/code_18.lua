local P = require("kvparse.core")

local M = {}

local function read_all(path)
  local f, err = io.open(path, "rb")
  if not f then return nil, "io_error:" .. tostring(err) end
  local d = f:read("*a"); f:close(); return d
end

local function show_error(path, text, err)
  io.stderr:write("Error: ", err, "\n")
  local ln = err:match("^parse_error:(%d+):")
  if ln then
    ln = tonumber(ln)
    local i = 0
    for line in (text.."\n"):gmatch("([^\n]*)\n") do
      i = i + 1
      if i == ln then
        io.stderr:write(string.format("%s:%d: %s\n", path, i, line), "\n")
        io.stderr:write(string.rep(" ", #path + 1 + #tostring(i) + 2)) -- rough caret align
        io.stderr:write("^\n")
        break
      end
    end
  end
end

function M.main(a)
  local path = a[1]
  if not path then
    io.stderr:write("usage: kvparse <file>\n"); return false
  end
  local text, e1 = read_all(path)
  if not text then show_error(path, "", e1); return false end
  local t, e2 = P.parse(text)
  if not t then show_error(path, text, e2); return false end
  for k, v in pairs(t) do print(k .. "=" .. v) end
  return true
end

return M