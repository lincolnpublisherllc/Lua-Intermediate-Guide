local function fail(code, detail)
  return nil, code .. (detail and (":" .. detail) or "")
end

-- usage
local function parse_num(s)
  local n = tonumber(s)
  if not n then return fail(E.bad_input, "not_number") end
  return n
end