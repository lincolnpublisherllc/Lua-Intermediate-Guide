-- scripts/bt/core.lua
local M = {}
local RUNNING, SUCCESS, FAILURE = "running","success","failure"

function M.sequence(children)
  return function(ctx)
    for i=ctx._i or 1, #children do
      ctx._i = i
      local r = children[i](ctx)
      if r ~= SUCCESS then return r end
    end
    ctx._i = nil
    return SUCCESS
  end
end

function M.selector(children)
  return function(ctx)
    for i=ctx._j or 1, #children do
      ctx._j = i
      local r = children[i](ctx)
      if r ~= FAILURE then return r end
    end
    ctx._j = nil
    return FAILURE
  end
end

M.RUNNING, M.SUCCESS, M.FAILURE = RUNNING, SUCCESS, FAILURE
return M