-- scripts/ai/goblin_bt.lua
local BT = require "scripts.bt.core"
local S, F, R = BT.SUCCESS, BT.FAILURE, BT.RUNNING

local function see_target(ctx)
  local e = ctx.self
  local t = ctx.find_target_in_range(e.pos, e.stats.vision)
  e.state.target = t
  return t and S or F
end

local function chase(ctx)
  local e, t = ctx.self, ctx.self.state.target
  if not t then return F end
  local done = ctx.move_towards(e, t.pos, e.stats.speed)
  return done and S or R
end

local function swing(ctx)
  local e, t = ctx.self, ctx.self.state.target
  if not t then return F end
  if ctx.distance(e.pos, t.pos) > 1.2 then return F end
  ctx.do_damage(e, t, 5)
  return S
end

local function idle(ctx)
  ctx.wait(0.2) -- yields in host; here we assume host advances timers
  return R
end

local tree = BT.selector{
  BT.sequence{ see_target, chase, swing },
  idle