-- main.lua (works with LÖVE or a simple loop)
local HR   = require "scripts.hotreload"
local Bus  = require "scripts.bus"
local spawn= require "scripts.spawn"

local world = { entities = {} }
local def = require "data.entities.goblin"
for i=1,30 do world.entities[i] = spawn(def, { x = i*0.5, y = 0 }) end

local reload_budget_ms = 2.0
local last_reload = 0

function love.update(dt)
  -- throttle reload checks to every 0.2s
  last_reload = last_reload + dt
  if last_reload >= 0.2 then
    HR.tick(function(mod, ok, payload)
      if ok then
        for _, e in ipairs(world.entities) do
          if e.brain_module == mod or e.id == "goblin" then
            e.brain = payload.new()
          end
        end
      else
        print("Reload failed:", payload)
      end
    end)
    last_reload = 0
  end

  -- tick AI with containment
  for i=1,#world.entities do
    local e = world.entities[i]
    local function tick_one()
      local ctx = {
        self = e,
        distance = function(a,b) local dx=a.x-b.x; local dy=a.y-b.y; return (dx*dx+dy*dy)^0.5 end,
        find_target_in_range = function(p, r) return world.player end,
        move_towards = function(ent, pos, speed) -- update ent.pos; return done?
          local dx, dy = pos.x - ent.pos.x, pos.y - ent.pos.y
          local d = math.sqrt(dx*dx+dy*dy); if d < 0.1 then return true end
          ent.pos.x = ent.pos.x + speed * dx/d * dt
          ent.pos.y = ent.pos.y + speed * dy/d * dt
          return false
        end,
        do_damage = function(src, dst, dmg) Bus.emit("damage", {src=src, dst=dst, dmg=dmg}) end,
        wait = function(_) end,
      }
      e.brain(ctx)
    end
    local ok, err = xpcall(tick_one, debug.traceback)
    if not ok then e.brain = function() return "failure" end; print("AI error:", err) end
  end
end