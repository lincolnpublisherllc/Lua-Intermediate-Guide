-- scripts/hotreload.lua
local lfs = require "lfs"

local M = { _watch = {} }

function M.watch(modname, path)
  M._watch[modname] = { path = path, mtime = lfs.attributes(path, "modification") or 0 }
end

local function reload(modname, path)
  package.loaded[modname] = nil
  local ok, mod = pcall(require, modname)
  if ok then
    M._watch[modname].mtime = lfs.attributes(path, "modification") or os.time()
    return true, mod
  else
    return false, mod -- error string
  end
end

function M.tick(on_reload)
  for modname, w in pairs(M._watch) do
    local mt = lfs.attributes(w.path, "modification")
    if mt and mt > w.mtime then
      local ok, mod_or_err = reload(modname, w.path)
      on_reload(modname, ok, mod_or_err)
    end
  end
end

return M