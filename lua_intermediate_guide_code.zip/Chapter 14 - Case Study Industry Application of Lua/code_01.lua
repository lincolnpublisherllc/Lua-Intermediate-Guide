-- data/entities/goblin.lua
return {
  id = "goblin",
  stats = { hp = 30, speed = 2.0, vision = 8.0 },
  brain = "ai.goblin_bt",              -- BT module path
  abilities = { "melee.swing", "move.chase" }