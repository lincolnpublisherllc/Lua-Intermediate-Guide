-- bootstrap (once at startup)
local HR = require "scripts.hotreload"