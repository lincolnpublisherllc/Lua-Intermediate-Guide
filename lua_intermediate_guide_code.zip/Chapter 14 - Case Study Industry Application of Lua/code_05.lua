return {
  new = function() return function(ctx) return tree(ctx) end end