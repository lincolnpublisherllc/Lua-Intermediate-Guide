  if ok then
    for _, e in ipairs(world.entities) do
      if e.brain and e.brain_module == mod then
        e.brain = payload.new()     -- swap behavior; keep e.state as-is
      end
    end
  else
    print("Reload error:", payload)
  end
end)