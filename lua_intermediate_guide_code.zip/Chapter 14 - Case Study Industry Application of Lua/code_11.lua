local obs = { n=0, total=0, max=0 }
local function time_block(f)
  local t0 = os.clock(); f(); local dt = os.clock() - t0
  obs.n, obs.total, obs.max = obs.n+1, obs.total+dt, math.max(obs.max, dt)
end