-- scripts/spawn.lua
local function spawn(def, pos)
  return {
    id = def.id,
    pos = { x = pos.x, y = pos.y },
    stats = def.stats,
    brain = require(def.brain).new(),   -- behavior tree instance
    state = { target = nil, cooldowns = {} },
  }
end