local function safe_tick(entity, dt)
  local ok, err = xpcall(function() entity.brain{ self=entity, dt=dt, ... } end, debug.traceback)
  if not ok then
    entity._err_count = (entity._err_count or 0) + 1
    if entity._err_count == 1 then print("AI error:", err) end
    if entity._err_count >= 3 then entity.brain = function() return "failure" end end
  else
    entity._err_count = 0
  end
end