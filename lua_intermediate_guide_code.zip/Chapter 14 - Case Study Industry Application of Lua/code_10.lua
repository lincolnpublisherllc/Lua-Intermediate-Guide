-- scripts/bus.lua
local Bus = { _subs = {} }

function Bus.on(topic, fn)
  local t = Bus._subs[topic] or {}; Bus._subs[topic] = t
  t[#t+1] = fn
end

function Bus.emit(topic, data)
  local t = Bus._subs[topic]; if not t then return end
  for i=1,#t do t[i](data) end
end

return Bus