-- scripts/sandbox.lua
local function safe_env(api)
  local env = {
    assert=assert, ipairs=ipairs, pairs=pairs, tostring=tostring,
    type=type, tonumber=tonumber, select=select, next=next,
    math = { abs=math.abs, min=math.min, max=math.max, floor=math.floor, random=math.random },
    string = { sub=string.sub, lower=string.lower, match=string.match },
    table = { insert=table.insert, remove=table.remove, sort=table.sort, concat=table.concat },
  }
  -- host API exposed explicitly
  for k,v in pairs(api or {}) do env[k] = v end
  return env
end

local function load_sandboxed(filepath, api)
  local src, err = io.open(filepath, "rb")
  if not src then return nil, err end
  local code = src:read("*a"); src:close()
  local chunk, perr = load(code, "@"..filepath, "t", safe_env(api))
  if not chunk then return nil, perr end
  return pcall(chunk)
end

return { load = load_sandboxed }