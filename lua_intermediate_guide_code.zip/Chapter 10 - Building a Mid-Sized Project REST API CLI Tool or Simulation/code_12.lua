-- src/dataprep/cli.lua
local Ingest   = require("dataprep.core.ingest")
local Stats    = require("dataprep.core.stats")
local Transform= require("dataprep.core.transform")
local Store    = require("dataprep.store.fs")
local Log      = require("dataprep.log")
local Color    = require("dataprep.color")
local Progress = require("dataprep.progress")
local Plugins  = require("dataprep.plugins")
local Config   = require("dataprep.config")

local M = {}

local function usage()
  print([[