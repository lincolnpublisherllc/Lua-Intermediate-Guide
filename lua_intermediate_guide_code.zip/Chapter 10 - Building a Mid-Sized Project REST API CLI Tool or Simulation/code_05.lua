-- src/dataprep/store/fs.lua
local json = (function()
  local ok, cj = pcall(require,"cjson")
  if ok then return cj else return require("dkjson") end
end)()

local M = {}

local function write_atomic(path, s)
  local dir = path:match("^(.*)/") or "."
  local tmp = string.format("%s/.tmp_%d_%d", dir, os.time(), math.random(1e6))
  local f = assert(io.open(tmp, "wb")); f:write(s); f:close()
  os.remove(path); assert(os.rename(tmp, path))
end

function M.write_json(path, t)
  local s = json.encode and json.encode(t) or json.encode(t, {indent=false})
  write_atomic(path, s)
  return true
end

function M.read_json(path)
  local f, err = io.open(path, "rb"); if not f then return nil, "io_open:"..tostring(err) end
  local d = f:read("*a"); f:close()
  if json.decode then return json.decode(d) else return json.decode(d) end
end

return M