    local rows = {{id=1},{id=2,name="a"}}
    assert.are.equal(2, S.count(rows))
    local m = S.missing_counts(rows, {"name"})
    assert.are.equal(1, m.name)
  end)
end)