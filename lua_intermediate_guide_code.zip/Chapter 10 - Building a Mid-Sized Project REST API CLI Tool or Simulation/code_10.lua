-- dataprep_plugin_sample.lua
local M = {}
function M.run(args, ctx)
  local log = ctx.log; log.info("plugin", {name="sample", arg=args[1] or "-"})
  print("hello from plugin:", args[1] or "(none)")
  return true
end
return M