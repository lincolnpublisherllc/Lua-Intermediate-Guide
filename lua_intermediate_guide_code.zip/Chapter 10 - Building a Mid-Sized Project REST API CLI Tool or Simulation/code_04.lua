-- src/dataprep/core/transform.lua
local dsl    = require("dsl")      -- from Ch.9
local engine = require("engine")   -- from Ch.9

local M = {}

function M.run_script(text)
  local ast, err = dsl.parse(text)
  if not ast then return nil, "parse_error:"..tostring(err) end
  local ok, n = pcall(engine.run, ast)
  if not ok then return nil, "exec_error:"..tostring(n) end
  return { written = n }
end

return M