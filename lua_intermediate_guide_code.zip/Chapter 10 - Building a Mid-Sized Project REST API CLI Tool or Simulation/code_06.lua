-- src/dataprep/log.lua
local M = {}
local rank = { trace=0, debug=1, info=2, warn=3, error=4 }
local cur = rank[(os.getenv("LOG_LEVEL") or "info")] or 2

local function line(lvl, msg, fields)
  if rank[lvl] < cur then return end
  local parts = {}
  for k,v in pairs(fields or {}) do parts[#parts+1] = k.."="..tostring(v) end
  io.stderr:write(string.format("%s %s %s\n", lvl:upper(), msg, table.concat(parts," ")))
end

return {
  trace=function(m,f) line("trace",m,f) end,
  debug=function(m,f) line("debug",m,f) end,
  info =function(m,f) line("info", m,f) end,
  warn =function(m,f) line("warn", m,f) end,
  error=function(m,f) line("error",m,f) end,