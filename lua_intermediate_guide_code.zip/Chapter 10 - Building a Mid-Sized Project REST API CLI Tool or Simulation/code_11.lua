-- src/dataprep/config.lua
local M = {}

local defaults = { out_dir = "out", schema = { id="number", name="string", price="number", qty="number" } }

local function safe_dofile(p)
  local ok, t = pcall(dofile, p)
  return ok and t or {}
end

function M.load()
  local filecfg = safe_dofile("dataprep.config.lua")
  local env = {}
  if os.getenv("DATAPREP_OUT") then env.out_dir = os.getenv("DATAPREP_OUT") end
  local cfg = {}
  for k,v in pairs(defaults) do cfg[k]=v end
  for k,v in pairs(filecfg) do cfg[k]=v end
  for k,v in pairs(env) do cfg[k]=v end
  return cfg
end

return M