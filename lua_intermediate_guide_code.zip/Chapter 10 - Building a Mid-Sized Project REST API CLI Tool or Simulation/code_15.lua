    local ok, err = V.schema_row({id="1",name="x",price="5",qty="2"},
      {id="number",name="string",price="number",qty="number"})
    assert.is_true(ok); assert.is_nil(err)
  end)
  it("rejects missing", function()
    local ok, err = V.schema_row({name="x"}, {id="number"})
    assert.is_nil(ok); assert.matches("^bad_input:missing_id", err)
  end)
end)
-- spec/stats_spec.lua
local S = require("dataprep.core.stats")