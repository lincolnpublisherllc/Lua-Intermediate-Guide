-- src/dataprep/plugins.lua
local M = {}

function M.run(name, args, ctx)
  local ok, mod = pcall(require, "dataprep_plugin_" .. name)
  if not ok then return nil, "not_found:plugin_"..name end
  if type(mod.run) ~= "function" then return nil, "bad_plugin:no_run" end
  return mod.run(args, ctx)
end

return M