-- src/dataprep/progress.lua
local M = {}
function M.bar(n, total, width)
  width = width or 30
  local k = total > 0 and math.floor((n/total)*width) or 0
  local filled = string.rep("#", k)
  local empty  = string.rep("-", width - k)
  return string.format("[%s%s] %d/%d", filled, empty, n, total)
end
return M