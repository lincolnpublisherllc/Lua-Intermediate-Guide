-- src/dataprep/core/validate.lua
local M = {}

function M.expect_table(x)  if type(x) ~= "table"  then return nil,"bad_input:table"  end return true end
function M.expect_string(x) if type(x) ~= "string" then return nil,"bad_input:string" end return true end

function M.schema_row(row, schema)
  for name, kind in pairs(schema) do
    local v = row[name]
    if v == nil or v == "" then return nil, "bad_input:missing_"..name end
    if kind == "number" and tonumber(v) == nil then return nil, "bad_input:not_number_"..name end
    if kind == "boolean" then
      if not (v == true or v == false or v == "true" or v == "false") then
        return nil, "bad_input:not_boolean_"..name
      end
    end
  end
  return true
end

return M