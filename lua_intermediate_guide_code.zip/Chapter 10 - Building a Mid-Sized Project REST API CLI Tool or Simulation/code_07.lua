-- src/dataprep/color.lua
local M = {}
local ESC = string.char(27).."["
function M.green(s) return ESC.."32m"..s..ESC.."0m" end
function M.red(s)   return ESC.."31m"..s..ESC.."0m" end
function M.yellow(s)return ESC.."33m"..s..ESC.."0m" end
return M