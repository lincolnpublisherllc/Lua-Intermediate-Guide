end

function M.main(argv)
  local cfg = Config.load()
  local cmd = argv[1]
  if not cmd or cmd == "help" then usage(); return true end

  if cmd == "ingest" then
    local path = argv[2]; if not path then print("usage: dataprep ingest <path>"); return false end
    local out_path = cfg.out_dir .. "/rows.jsonl"
    local f = assert(io.open(out_path, "w"))
    local total, acc = 0, 0
    local res, err = Ingest.ingest_csv(path, cfg.schema, function(row)
      -- simple JSONL write
      local s = string.format('{"id":%s,"name":"%s","price":%s,"qty":%s}\n',
        row.id, row.name, row.price, row.qty)
      f:write(s); acc = acc + 1
      if acc % 100 == 0 then io.stderr:write(Progress.bar(acc, total > 0 and total or acc), "\r") end
    end)
    f:close()
    if not res then Log.error("ingest failed", { err = err }); return false end
    print(Color.green(("imported=%d rejected=%d -> %s"):format(res.imported, res.rejected, out_path)))
    return true

  elseif cmd == "transform" then
    local script = argv[2]; if not script then print("usage: dataprep transform <rules.dsl>"); return false end
    local f = assert(io.open(script, "rb")); local text = f:read("*a"); f:close()
    local ok, data = Transform.run_script(text)
    if not ok then Log.error("transform failed", { err = data }); return false end
    print(Color.green(("wrote_rows=%d"):format(data.written))); return true

  elseif cmd == "stats" then
    local rows = {}
    local in_path = cfg.out_dir .. "/rows.jsonl"
    local rf = io.open(in_path, "r"); if not rf then Log.warn("no rows.jsonl", { path = in_path }); return true end
    for line in rf:lines() do
      local id,name,price,qty = line:match('%"id%":(%d+).-"name%":"(.-)".-"price%":([%d%.]+).-"qty%":(%d+)')
      rows[#rows+1] = { id=tonumber(id), name=name, price=tonumber(price), qty=tonumber(qty) }
    end
    rf:close()
    local cnt = Stats.count(rows)
    local miss = Stats.missing_counts(rows, {"id","name","price","qty"})
    print(("rows=%d  missing_id=%d missing_name=%d missing_price=%d missing_qty=%d")
      :format(cnt, miss.id, miss.name, miss.price, miss.qty))
    return true

  elseif cmd == "plugin" then
    local name = argv[2]; if not name then print("usage: dataprep plugin <name> [args...]"); return false end
    local ok, err = Plugins.run(name, { select(3, table.unpack(argv)) }, { log = Log, cfg = cfg })
    if not ok then Log.error("plugin error", { err = err }); return false end
    return true
  else
    usage(); return false
  end
end

return M
-- src/dataprep/main.lua
local cli = require("dataprep.cli")

local function crash(msg)
  local DEBUG = os.getenv("DATAPREP_DEBUG") == "1"
  if DEBUG then return debug.traceback("Fatal: "..tostring(msg), 2) end
  return "Fatal: "..tostring(msg)
end

local function top()
  local ok = cli.main(arg)
  if not ok then error("failed") end
end

local ok, err = xpcall(top, crash)
if not ok then io.stderr:write(err, "\n"); os.exit(1) end