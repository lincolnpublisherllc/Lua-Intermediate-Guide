-- src/dataprep/core/stats.lua
local M = {}

function M.count(rows) return #rows end

function M.missing_counts(rows, fields)
  local out = {}; for _, f in ipairs(fields) do out[f] = 0 end
  for _, r in ipairs(rows) do
    for _, f in ipairs(fields) do
      local v = r[f]; if v == nil or v == "" then out[f] = out[f] + 1 end
    end
  end
  return out
end

return M