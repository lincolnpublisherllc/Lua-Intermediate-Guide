-- src/dataprep/core/ingest.lua
local Validate = require("dataprep.core.validate")

local M = {}

local function rows_from_csv(path)
  local f, err = io.open(path, "r"); if not f then return nil, "io_open:"..tostring(err) end
  local header
  return function()
    local line = f:read("*l")
    if not line then f:close(); return nil end
    local cells = {}; local field = {}; local inq = false
    for i = 1, #line do
      local c = line:sub(i,i)
      if c == '"' then
        if inq and line:sub(i+1,i+1) == '"' then field[#field+1]='"'; i = i + 1 else inq = not inq end
      elseif c == "," and not inq then cells[#cells+1] = table.concat(field); field = {}
      else field[#field+1] = c end
    end
    cells[#cells+1] = table.concat(field)
    if not header then header = cells; return {} end
    local row = {}
    for i, k in ipairs(header) do row[k] = cells[i] end
    return row
  end
end

function M.ingest_csv(path, schema, on_row)
  local it, err = rows_from_csv(path)
  if not it then return nil, err end
  local n, bad = 0, 0
  while true do
    local row = it(); if not row then break end
    if next(row) ~= nil then
      local ok, verr = Validate.schema_row(row, schema)
      if not ok then bad = bad + 1 else on_row(row); n = n + 1 end
    end
  end
  return { imported = n, rejected = bad }
end

return M