    -- You can spawn a Lua process to run main.lua with no args and capture stdout
    assert.is_true(true) -- keep simple for this book
  end)
end)