local pl = require "pl.import_into"()  -- brings in pl.tablex, pl.stringx, etc.

local nums = {3, 10, 5, 8}
local evens = pl.tablex.filter(nums, function(x) return x % 2 == 0 end)
local doubled = pl.tablex.map(function(x) return x*2 end, evens)
local sum = pl.tablex.reduce('+', doubled, 0)
-- evens={10,8}, doubled={20,16}, sum=36