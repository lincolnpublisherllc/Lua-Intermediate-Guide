local pl = require "pl.import_into"()

local defaults = { port=8080, log="info", paths={ data="data/", out="out/" } }

local function try_dofile(path)
  local ok, t = pcall(dofile, path)
  return ok and t or {}
end

local filecfg = try_dofile("config.lua")
local envcfg  = {}
if os.getenv("APP_PORT") then envcfg.port = tonumber(os.getenv("APP_PORT")) end
if os.getenv("APP_LOG")  then envcfg.log  = os.getenv("APP_LOG") end

local cfg = pl.tablex.deepcopy(defaults)