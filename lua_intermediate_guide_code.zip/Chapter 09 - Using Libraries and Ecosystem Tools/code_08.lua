local date = require "date"

local now = date(true)                   -- UTC now
print(now:fmt("%Y-%m-%dT%H:%M:%SZ"))
local later = now:addminutes(15)
print((later - now):spanseconds())       -- 900