local function logger(out, level)
  out, level = out or io.stderr, level or "info"
  local rank = { trace=0, debug=1, info=2, warn=3, error=4 }
  local cur = rank[level] or 2

  local function log(lvl, msg, fields)
    if rank[lvl] < cur then return end
    local parts = {}
    for k,v in pairs(fields or {}) do parts[#parts+1] = k .. "=" .. tostring(v) end
    out:write(string.format("%s %s %s\n", lvl:upper(), msg, table.concat(parts, " ")))
  end

  return {
    trace=function(m,f) log("trace", m,f) end,
    debug=function(m,f) log("debug", m,f) end,
    info=function(m,f)  log("info",  m,f) end,
    warn=function(m,f)  log("warn",  m,f) end,
    error=function(m,f) log("error", m,f) end,
  }
end

-- usage
local log = logger(io.stderr, os.getenv("LOG_LEVEL") or "info")