-- trans.lua
local argparse = require "argparse"
local dsl = require "dsl"
local engine = require "engine"

local p = argparse("trans", "Transform CSV via a tiny DSL")