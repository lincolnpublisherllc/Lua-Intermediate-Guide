local lpeg = require "lpeg"
local P, R, S, C = lpeg.P, lpeg.R, lpeg.S, lpeg.C

local space  = S(" \t\r\n")^0
local digit  = R("09")
local number = C(digit^1) / tonumber
local plus   = P("+")
local expr   = space * number * space * plus * space * number * space

print(expr:match(" 12 + 30 "))  -- prints 30 because we only captured the second number (fix below)