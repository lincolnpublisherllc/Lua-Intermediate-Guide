if ok and code == 200 then
  local body = table.concat(resp)
  print("len=", #body)