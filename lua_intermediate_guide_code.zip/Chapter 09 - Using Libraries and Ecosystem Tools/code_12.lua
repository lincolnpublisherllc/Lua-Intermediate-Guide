function Obs.new()
  return setmetatable({ counters={}, timers={} }, Obs)
end

function Obs:inc(name, n) self.counters[name] = (self.counters[name] or 0) + (n or 1) end

function Obs:time(name, f)
  local t0 = os.clock()
  local ok, res = pcall(f)
  local dt = os.clock() - t0
  local T = self.timers[name] or { n=0, total=0.0, max=0.0 }
  T.n, T.total, T.max = T.n+1, T.total+dt, math.max(T.max, dt)
  self.timers[name] = T
  if not ok then error(res, 0) end
  return res
end

function Obs:snapshot()
  local out = { counters=self.counters, timers={} }
  for k, t in pairs(self.timers) do
    out.timers[k] = { n=t.n, avg=(t.n>0 and t.total/t.n or 0.0), max=t.max }
  end
  return out
end