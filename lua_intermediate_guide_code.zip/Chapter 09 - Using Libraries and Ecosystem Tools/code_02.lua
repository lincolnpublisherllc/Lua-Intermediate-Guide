local sx = require "pl.stringx"
local path = require "pl.path"
local dir  = require "pl.dir"

print(sx.split("a,b,,c", ","))             -- handles empty fields
print(path.splitext("logs/app.log"))       -- {"logs/app",".log"}
for _, f in ipairs(dir.getfiles("logs", "*.log")) do print(f) end