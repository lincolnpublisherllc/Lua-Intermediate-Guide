-- csvio.lua
local csv = require "pl.csv"
local path = require "pl.path"

local M = {}

function M.read_rows(p)
  local rows = {}
  for row in csv.lines(p, { headers=true }) do
    rows[#rows+1] = row
  end
  return rows
end

function M.write_rows(p, rows)
  local f = assert(io.open(p, "w"))
  local headers = {}
  for k in pairs(rows[1] or {}) do headers[#headers+1] = k end
  table.sort(headers)
  f:write(table.concat(headers, ","), "\n")
  for _, r in ipairs(rows) do
    local cells = {}
    for _, h in ipairs(headers) do cells[#cells+1] = r[h] or "" end
    f:write(table.concat(cells, ","), "\n")
  end
  f:close()
end

return M