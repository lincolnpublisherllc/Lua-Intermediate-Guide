local http = require "socket.http"
local ltn12 = require "ltn12"

local resp = {}
local ok, code = http.request{
  url = "https://httpbin.org/get",
  sink = ltn12.sink.table(resp),
  method = "GET",
  redirect = true,