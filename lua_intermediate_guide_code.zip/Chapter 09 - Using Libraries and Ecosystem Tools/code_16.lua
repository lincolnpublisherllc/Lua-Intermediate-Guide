-- engine.lua
local csvio = require "csvio"
local sx    = require "pl.stringx"

local M = {}

local function eval_expr(expr, row)
  local tag = expr[1]
  if tag == "num" then return expr[2]
  elseif tag == "id" then
    local v = row[expr[2]]
    local n = tonumber(v)
    return n or v
  elseif tag == "neg" then return -eval_expr(expr[2], row)
  elseif tag == "not" then return not eval_expr(expr[2], row)
  else
    local op, a, b = tag, expr[2], expr[3]
    local va, vb = eval_expr(a, row), eval_expr(b, row)
    if op == "+" then return va + vb
    elseif op == "-" then return va - vb
    elseif op == "*" then return va * vb
    elseif op == "/" then return va / vb
    elseif op == "==" then return va == vb
    elseif op == "!=" then return va ~= vb
    elseif op == "<"  then return va <  vb
    elseif op == ">"  then return va >  vb
    elseif op == "<=" then return va <= vb
    elseif op == ">=" then return va >= vb
    elseif op == "and" then return va and vb
    elseif op == "or"  then return va or  vb
    else error("unknown op "..tostring(op))
    end
  end
end

local function run(ast)
  local ctx = { rows=nil, out=nil, select_cols=nil, where=nil, derivations={} }

  for _, step in ipairs(ast) do
    if step.op == "load" then
      ctx.rows = csvio.read_rows(step.path)
    elseif step.op == "select" then
      ctx.select_cols = step.cols
    elseif step.op == "where" then
      ctx.where = step.expr
    elseif step.op == "derive" then
      ctx.derivations[#ctx.derivations+1] = step
    elseif step.op == "save" then
      ctx.out = step.path
    else
      error("unknown step: "..tostring(step.op))
    end
  end

  assert(ctx.rows, "no load step")
  local out = {}

  for _, row in ipairs(ctx.rows) do
    if not ctx.where or eval_expr(ctx.where, row) then
      local r = {}
      if ctx.select_cols then
        for _, c in ipairs(ctx.select_cols) do r[c] = row[c] end
      else
        for k,v in pairs(row) do r[k] = v end
      end
      for _, d in ipairs(ctx.derivations) do
        r[d.name] = eval_expr(d.expr, r)
      end
      out[#out+1] = r
    end
  end

  assert(ctx.out, "no save step")
  csvio.write_rows(ctx.out, out)
  return true, #out
end

M.run = run
M.eval_expr = eval_expr
return M