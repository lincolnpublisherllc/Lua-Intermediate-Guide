local argparse = require "argparse"

local p = argparse("trans", "Transform CSV files with a DSL")