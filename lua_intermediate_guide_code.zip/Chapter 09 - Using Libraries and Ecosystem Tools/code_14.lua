-- dsl.lua
local lpeg  = require "lpeg"
local S, R, P, C, Cc, Cg, Ct, V = lpeg.S, lpeg.R, lpeg.P, lpeg.C, lpeg.Cc, lpeg.Cg, lpeg.Ct, lpeg.V

local space = S(" \t\r\n")^0
local alpha = R("AZ","az","__")
local alnum = R("AZ","az","__","09")
local ident = C(alpha * alnum^0) * space

local dqstr = P('"') * C((P(1) - P('"'))^0) * P('"') * space
local num   = C((S("+-")^-1 * R("09")^1 * (P(".") * R("09")^1)^-1)) / tonumber * space

local kw = {}
local function KW(s) kw[s] = true; return P(s) * -alnum * space end

-- Expression grammar (recursive descent via LPeg)
local G = P{
  "Script",
  Script   = space * Ct((V"Step")^1) * -1,
  Step     = V"Load" + V"Select" + V"Where" + V"Derive" + V"Save",

  Load     = KW"load" * dqstr / function(path) return {op="load", path=path} end,
  Save     = KW"save" * dqstr / function(path) return {op="save", path=path} end,

  Select   = KW"select" * KW"columns:" * Ct(ident * (P(",")*space * ident)^0)
               / function(cols) return {op="select", cols=cols} end,

  Derive   = KW"derive" * ident * P("=") * space * V"Expr"
               / function(name, expr) return {op="derive", name=name, expr=expr} end,

  Where    = KW"where" * V"Expr" / function(expr) return {op="where", expr=expr} end,

  -- Expr with precedence: or < and < cmp < add < mul < unary < primary
  Expr     = V"Or",
  Or       = V"And" * Ct((KW"or"  * V"And")^0) / function(a,rest)
                for i=1,#rest do a = {"or", a, rest[i]} end; return a end,
  And      = V"Cmp" * Ct((KW"and" * V"Cmp")^0) / function(a,rest)
                for i=1,#rest do a = {"and", a, rest[i]} end; return a end,
  Cmp      = V"Add" * Ct(( (P("==")+P("!=")+P("<=")+P(">=")+P("<")+P(">")) * space * V"Add")^0)
              / function(a, rest)
                  for i=1,#rest,2 do a = {rest[i], a, rest[i+1]} end; return a
                end,
  Add      = V"Mul" * Ct(( (P("+")+P("-")) * space * V"Mul")^0)
              / function(a, rest)
                  for i=1,#rest,2 do a = {rest[i], a, rest[i+1]} end; return a
                end,
  Mul      = V"Unary" * Ct(( (P("*")+P("/")) * space * V"Unary")^0)
              / function(a, rest)
                  for i=1,#rest,2 do a = {rest[i], a, rest[i+1]} end; return a
                end,
  Unary    = (KW"not" * V"Unary") / function(x) return {"not", x} end
           + (P("-")*space * V"Unary") / function(x) return {"neg", x} end
           + V"Primary",
  Primary  = (P("(")*space * V"Expr" * P(")")*space)
           + num / function(n) return {"num", n} end
           + ident / function(id) return {"id", id} end,