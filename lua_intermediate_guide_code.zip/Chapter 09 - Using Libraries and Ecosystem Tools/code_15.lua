local function parse(script)
  local ast = G:match(script)
  if not ast then return nil, "parse_error" end
  return ast
end

return { parse = parse }