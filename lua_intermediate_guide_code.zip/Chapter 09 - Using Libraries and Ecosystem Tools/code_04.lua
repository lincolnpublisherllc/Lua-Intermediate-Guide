local V = lpeg.V
local G = lpeg.P{
  "Expr",
  Expr = lpeg.Cf(lpeg.Ct(V"Term" * (space * S("+-") * space * V"Term")^0), function(acc, op, val)
    if type(acc) == "table" then acc = acc[1] end
    return (op == "+") and (acc + val) or (acc - val)
  end),
  Term = number