local args = p:parse()

local function slurp(pth)
  local f, e = io.open(pth, "rb"); if not f then error(e) end
  local d = f:read("*a"); f:close(); return d
end

local script = slurp(args.script)
local ast, err = dsl.parse(script)
if not ast then
  io.stderr:write("parse error: ", tostring(err), "\n")
  os.exit(1)
end

local ok, n = pcall(engine.run, ast)
if not ok then
  io.stderr:write("run error: ", tostring(n), "\n")
  os.exit(2)