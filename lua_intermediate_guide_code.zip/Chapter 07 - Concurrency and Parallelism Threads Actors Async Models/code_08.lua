local tokens, capacity, refill, last = 0, 10, 5, os.clock()

local function allow()
  local now = os.clock()
  local dt = now - last; last = now
  tokens = math.min(capacity, tokens + dt * refill)
  if tokens >= 1 then tokens = tokens - 1; return true end
  return false
end