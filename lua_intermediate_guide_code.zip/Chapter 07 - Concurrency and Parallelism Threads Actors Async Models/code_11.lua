local function now_clock()
  return os.clock()   -- wall-clock alternatives: os.time() with seconds
end

local function default_backoff(tries)
  -- 0.5s, 1s, 2s, 4s capped at 5s
  local t = math.min(5.0, 0.5 * (2 ^ (tries - 1)))
  return t
end

local function minheap_new()
  return { a = {}, n = 0 }
end
local function heap_push(h, item, key)
  h.n = h.n + 1; h.a[h.n] = {item=item, key=key}
  local i = h.n
  while i > 1 do
    local p = math.floor(i/2)
    if h.a[i].key < h.a[p].key then h.a[i], h.a[p] = h.a[p], h.a[i]; i = p else break end
  end
end
local function heap_peek(h) if h.n == 0 then return nil end return h.a[1].item, h.a[1].key end
local function heap_pop(h)
  if h.n == 0 then return nil end
  local top = h.a[1]; h.a[1] = h.a[h.n]; h.a[h.n] = nil; h.n = h.n - 1
  local i = 1
  while true do
    local l, r, s = 2*i, 2*i+1, i
    if l <= h.n and h.a[l].key < h.a[s].key then s = l end
    if r <= h.n and h.a[r].key < h.a[s].key then s = r end
    if s == i then break end
    h.a[i], h.a[s] = h.a[s], h.a[i]; i = s
  end
  return top.item, top.key
end

function Runner.new(opts)
  opts = opts or {}
  return setmetatable({
    now = opts.now or now_clock,
    backoff = opts.backoff or default_backoff,
    heap = minheap_new(),
    tasks = {},  -- id -> task
    next_id = 0,
    running = false,
  }, Runner)
end

function Runner:schedule(f, delay)
  self.next_id = self.next_id + 1
  local id = tostring(self.next_id)
  local t = { id = id, f = f, tries = 0, next_at = self.now() + (delay or 0), canceled = false }
  self.tasks[id] = t
  heap_push(self.heap, t, t.next_at)
  return id
end

function Runner:cancel(id)
  local t = self.tasks[id]; if t then t.canceled = true; return true end
  return false
end

local function run_once(self, task)
  if task.canceled then return true end
  task.tries = task.tries + 1
  local ok, err = coroutine.resume(coroutine.create(task.f), self, task)
  if ok then
    -- success, remove
    self.tasks[task.id] = nil
    return true
  else
    -- failed, schedule retry
    local delay = self.backoff(task.tries)
    task.next_at = self.now() + delay
    heap_push(self.heap, task, task.next_at)
    return false, err
  end
end

function Runner:advance(dt)
  local target = self.now() + (dt or 0)
  while true do
    local top, at = heap_peek(self.heap)
    if not top or at > target then break end
    heap_pop(self.heap)
    local ok, err = run_once(self, top)
    if not ok then
      io.stderr:write(string.format("task %s failed (try %d): %s\n", top.id, top.tries, tostring(err)))
    end
  end
end

function Runner:run_for(seconds, tick)
  tick = tick or 0.05
  local stop_at = self.now() + seconds
  while self.now() < stop_at do
    self:advance(0)  -- process ready tasks
    if package.config:sub(1,1) == "\\" then
      os.execute("ping -n 1 -w " .. math.ceil(tick*1000) .. " 127.0.0.1 > NUL")
    else
      os.execute("sleep " .. tostring(tick))
    end
  end
end

return Runner