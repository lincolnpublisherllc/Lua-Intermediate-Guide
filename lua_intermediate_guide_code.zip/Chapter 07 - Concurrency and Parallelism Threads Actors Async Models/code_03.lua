local uv = require("luv")

local function sleep(ms)
  return coroutine.yield(function(resume)
    local t = uv.new_timer()
    uv.timer_start(t, ms, 0, function()
      uv.timer_stop(t); uv.close(t); resume(true)
    end)
  end)
end

local function run_co(f)
  local co = coroutine.create(f)
  local function step(ok, val)
    if not ok then error(val) end
    if coroutine.status(co) == "dead" then return end
    -- val is a function that takes resume
    val(function(...)
      step(coroutine.resume(co, ...))
    end)
  end
  step(coroutine.resume(co))
end