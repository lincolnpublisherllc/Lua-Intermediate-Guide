local function worker(name, n)
  for i = 1, n do
    print(name, i)
    coroutine.yield()       -- give someone else a turn
  end
  return name .. " done"
end

local a = coroutine.create(worker)
local b = coroutine.create(worker)
print(coroutine.resume(a, "A", 2))  -- true, nil printed from worker
print(coroutine.resume(b, "B", 3))
print(coroutine.resume(a))          -- resume where A left off
print(coroutine.resume(b))
print(coroutine.resume(b))