local uv = require("luv")

local function set_timeout(ms, f)
  local t = uv.new_timer()
  uv.timer_start(t, ms, 0, function()
    uv.timer_stop(t); uv.close(t); f()
  end)
  return t
end