  print("start")
  sleep(300)  -- yields
  print("after 300ms")
  sleep(300)
  print("done")
end)