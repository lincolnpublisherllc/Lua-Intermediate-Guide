-- simple scheduler tick
for _ = 1, 3 do counter.step() end