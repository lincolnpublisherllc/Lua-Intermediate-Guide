local pq = {}  -- pending jobs
local running = 0
local max_running = 4

local function submit(job) pq[#pq+1] = job end

local function tick()
  while running < max_running and #pq > 0 do
    local job = table.remove(pq, 1)
    running = running + 1
    coroutine.wrap(function()
      local ok, err = pcall(job)
      if not ok then io.stderr:write("job failed: ", err, "\n") end
      running = running - 1
    end)()
  end
end

-- loop:
-- while true do tick(); sleep a little; end