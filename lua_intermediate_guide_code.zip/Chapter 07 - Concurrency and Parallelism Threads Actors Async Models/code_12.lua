local Runner = require("runner")
local R = Runner.new()

local idA = R:schedule(function(self, task)
  print("A running"); error("boom")
end, 0.0)

local idB = R:schedule(function(self, task)
  print("B runs once and completes")
end, 0.2)

-- Cancel A after first failure