local function mailbox()
  local q = {}
  return {
    send = function(msg) q[#q+1] = msg end,
    recv = function()
      while #q == 0 do coroutine.yield() end
      local m = q[1]; table.remove(q,1); return m
    end
  }
end

local function spawn(actor_fn)
  local mbox = mailbox()
  local co = coroutine.create(function() actor_fn(mbox) end)
  return {
    send = mbox.send,
    step = function() if coroutine.status(co) ~= "dead" then coroutine.resume(co) end end,
    alive = function() return coroutine.status(co) ~= "dead" end
  }
end

-- Example actor: a counter that reports totals
local counter = spawn(function(m)
  local total = 0
  while true do
    local msg = m.recv()
    if msg.kind == "add" then total = total + msg.n
    elseif msg.kind == "get" then msg.reply(total)
    elseif msg.kind == "stop" then return end
  end
end)