-- content_by_lua_block
local http = require "resty.http"
local c = http.new()
local res, err = c:request_uri("http://service/api", { method = "GET", keepalive = 10000 })
if not res then
  ngx.status = 502; ngx.say("upstream error"); return
end