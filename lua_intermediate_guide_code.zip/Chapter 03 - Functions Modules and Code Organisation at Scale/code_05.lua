-- src/cache.lua
local Cache = {}