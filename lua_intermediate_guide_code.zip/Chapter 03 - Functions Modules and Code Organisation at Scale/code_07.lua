local Cache = require("cache")
local c = Cache.new()