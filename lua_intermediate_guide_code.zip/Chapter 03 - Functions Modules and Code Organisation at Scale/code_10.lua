local writes = {}
local fake_out = { write = function(s) table.insert(writes, s) end }
local fake_now = function() return 1234567890 end
local fake_fmt = function(_, t) return "T"..t end

local Reporter = require("report.reporter")
local r = Reporter.new{ out = fake_out, now = fake_now, fmt = fake_fmt }