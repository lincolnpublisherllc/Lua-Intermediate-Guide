local billing = require("billing.core")

local M = {}

function M.main(a)
  -- demo data
  local lines = {
    {qty=2, price=4500.00},
    {qty=1, price=12999.50},
  }
  local total = billing.total(lines, {discount={kind="percent", value=10}, tax_rate=0.075})
  print(string.format("Total: %.2f", total))
  return true
end

return M