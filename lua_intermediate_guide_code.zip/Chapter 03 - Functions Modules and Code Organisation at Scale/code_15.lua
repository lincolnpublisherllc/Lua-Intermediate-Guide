-- spec/cache_lru_spec.lua
local contract = require("spec.cache_contract")