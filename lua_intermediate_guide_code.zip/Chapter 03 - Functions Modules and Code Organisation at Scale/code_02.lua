-- src/billing/core.lua
local M = {}

-- private helper
local function round2(x) return math.floor(x * 100 + 0.5) / 100 end

-- public
function M.total(lines)
  local sum = 0
  for _, ln in ipairs(lines) do
    sum = sum + (ln.qty * ln.price)
  end
  return round2(sum)
end

return M