-- src/counter.lua
local function new_counter(start)
  local n = start or 0
  return {
    inc = function() n = n + 1; return n end,
    get = function() return n end
  }
end
return { new = new_counter }