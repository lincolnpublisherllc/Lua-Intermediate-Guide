function Cache.new()
  return setmetatable({ data = {} }, Cache)
end

function Cache:get(k) return self.data[k] end
function Cache:set(k, v) self.data[k] = v end

return Cache