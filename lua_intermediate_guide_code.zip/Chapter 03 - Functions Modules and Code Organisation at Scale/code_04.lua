-- src/billing/init.lua (facade)
local M = {}
M.core    = require("billing.core")
M.tax     = require("billing.tax")
M.disc    = require("billing.discount")
return M