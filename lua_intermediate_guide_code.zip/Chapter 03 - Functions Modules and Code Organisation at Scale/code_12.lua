-- src/inventory/store.lua
local function Store(stock, pricing, audit)
  -- stock: { has(id), add(id, qty), take(id, qty) }
  -- pricing: { price(id) }
  -- audit: { event(name, data) }
  local M = {}

  function M.buy(id, qty)
    if not stock.has(id) then return nil, "not_found" end
    stock.take(id, qty)
    audit.event("buy", {id=id, qty=qty, total=pricing.price(id)*qty})
    return true
  end

  return M
end

return Store