-- src/report/reporter.lua
local M = {}

function M.new(opts)
  opts = opts or {}
  local out = opts.out or io
  local now = opts.now or os.time
  local fmt = opts.fmt or os.date

  local R = {}

  function R:info(msg)
    local ts = fmt("%Y-%m-%d %H:%M:%S", now())
    out.write(string.format("[%s] INFO: %s\n", ts, msg))
  end

  return R
end

return M