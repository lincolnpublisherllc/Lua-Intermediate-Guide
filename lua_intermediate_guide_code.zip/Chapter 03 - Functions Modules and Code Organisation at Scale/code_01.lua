-- pure logic: safe, testable
local function average(nums)
  if #nums == 0 then return nil, "empty" end
  local s = 0
  for i = 1, #nums do s = s + nums[i] end
  return s / #nums
end

-- effectful wrapper: formatting & output
local function print_average(nums, writer)
  writer = writer or io.write
  local avg, err = average(nums)
  if not avg then
    writer("error: " .. err .. "\n"); return false
  end
  writer(string.format("avg=%.2f\n", avg))
  return true
end