-- spec/cache_table_spec.lua
local contract = require("spec.cache_contract")