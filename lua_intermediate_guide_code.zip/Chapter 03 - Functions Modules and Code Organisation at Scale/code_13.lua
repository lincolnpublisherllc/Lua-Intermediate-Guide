-- spec/cache_contract.lua
local function contract(make_cache)
  describe("cache contract", function()
    it("sets and gets", function()
      local c = make_cache()
      c:set("a", 1)
      assert(c:get("a") == 1)
    end)
  end)
end

return contract