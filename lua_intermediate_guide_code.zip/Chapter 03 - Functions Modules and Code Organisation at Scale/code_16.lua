-- src/billing/core.lua
local M = {}

local function round2(x) return math.floor(x*100 + 0.5)/100 end

function M.subtotal(lines)
  local s = 0
  for _, ln in ipairs(lines) do s = s + ln.qty * ln.price end
  return round2(s)
end

function M.apply_discount(amount, rule)
  rule = rule or { kind="none" }
  if rule.kind == "percent" then return round2(amount * (1 - rule.value/100)) end
  if rule.kind == "fixed"   then return round2(math.max(0, amount - rule.value)) end
  return amount
end

function M.tax(amount, rate)
  return round2(amount * (rate or 0))
end

function M.total(lines, opts)
  opts = opts or {}
  local sub  = M.subtotal(lines)
  local disc = M.apply_discount(sub, opts.discount)
  return round2(disc + M.tax(disc, opts.tax_rate or 0))
end

return M