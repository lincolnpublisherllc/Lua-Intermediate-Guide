function Account:set_limit(n)
  assert(type(n) == "number" and n >= 0, "limit>=0")
  self.limit = n
end