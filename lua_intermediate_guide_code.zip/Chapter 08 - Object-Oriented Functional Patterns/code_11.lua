-- lines(path) -> iterator
local function lines(path)
  local f = assert(io.open(path, "r"))
  return function()
    local l = f:read("*l")
    if l then return l else f:close(); return nil end
  end
end

for line in lines("data.txt") do
  print(line)
end