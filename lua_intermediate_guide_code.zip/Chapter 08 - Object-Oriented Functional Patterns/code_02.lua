function Account.new(balance)
  assert(type(balance) == "number" and balance >= 0, "balance>=0")
  return setmetatable({ balance = balance }, Account)
end

function Account:deposit(n)
  assert(type(n) == "number" and n > 0, "deposit>0")
  self.balance = self.balance + n
  return self
end

function Account:withdraw(n)
  assert(n > 0 and n <= self.balance, "insufficient")
  self.balance = self.balance - n
  return self
end

function Account:get() return self.balance end

return Account