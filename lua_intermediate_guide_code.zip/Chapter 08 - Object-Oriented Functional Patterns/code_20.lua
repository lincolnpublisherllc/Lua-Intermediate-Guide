function Cart.new(inv)
  return setmetatable({ inv = inv, lines = {} }, Cart)
end

function Cart:add(id, qty)
  qty = qty or 1
  local item = self.inv.items[id]; assert(item, "unknown item")
  -- reserve stock
  local _, taken = self.inv:take(id, qty)
  -- accumulate line
  local line = self.lines[id] or { id=id, name=item.name, price=item.price, qty=0 }
  line.qty = line.qty + taken
  self.lines[id] = line
end

function Cart:remove(id, qty)
  qty = qty or 1
  local line = assert(self.lines[id], "not in cart")
  assert(line.qty >= qty, "too many")
  line.qty = line.qty - qty
  self.inv:put_back(id, qty)
  if line.qty == 0 then self.lines[id] = nil end
end

function Cart:summary(opts)
  local lines = {}
  for _, ln in pairs(self.lines) do lines[#lines+1] = { price=ln.price, qty=ln.qty } end
  local sub = Pricing.subtotal(lines)
  local tot = Pricing.total(lines, opts or {})
  return { subtotal=sub, total=tot, count=#lines }
end

function Cart:checkout(opts)
  -- in a real app: persist order, handle payment, etc.
  local s = self:summary(opts)
  self.lines = {}
  return s
end

return Cart