-- shop/item.lua
local Item = {}