local function with(t, updates)
  local r = {}
  for k,v in pairs(t) do r[k] = v end
  for k,v in pairs(updates) do r[k] = v end
  return r
end

local user = { id=1, name="Ada", active=true }
local user2 = with(user, { active=false })  -- user unchanged