function Inventory.new()
  return setmetatable({ items = {}, stock = {} }, Inventory)
end

function Inventory:add_item(item, qty)
  assert(item and item.id)
  self.items[item.id] = item
  self.stock[item.id] = (self.stock[item.id] or 0) + (qty or 0)
end

function Inventory:has(id) return (self.stock[id] or 0) > 0 end

function Inventory:take(id, qty)
  qty = qty or 1
  local have = self.stock[id] or 0
  assert(have >= qty, "insufficient")
  self.stock[id] = have - qty
  return self.items[id], qty
end

function Inventory:put_back(id, qty)
  self.stock[id] = (self.stock[id] or 0) + (qty or 1)
end

return Inventory