-- price.lua
local function Price(amount, currency)
  assert(type(amount) == "number" and amount >= 0)
  assert(currency == "USD" or currency == "NGN" or currency == "EUR")
  return { amount = amount, currency = currency }
end

return Price