local function deep_merge(a,b)
  local r = {}
  for k,v in pairs(a or {}) do r[k]=v end
  for k,v in pairs(b or {}) do
    r[k] = (type(v)=="table" and type(r[k])=="table") and deep_merge(r[k], v) or v
  end
  return r
end