local function range(a,b,step)
  step = step or 1
  local i = a - step
  return function()
    i = i + step
    if i <= b then return i end
  end
end