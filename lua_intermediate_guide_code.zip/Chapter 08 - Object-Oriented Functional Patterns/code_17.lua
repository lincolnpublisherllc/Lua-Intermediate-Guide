-- shop/inventory.lua
local Inventory = {}