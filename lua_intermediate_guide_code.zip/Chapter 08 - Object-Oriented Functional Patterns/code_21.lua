local Item = require("shop.item")
local Inventory = require("shop.inventory")
local Cart = require("shop.cart")

local inv = Inventory.new()