local F = {}

function F.map(t, f)
  local out = {}
  for i, v in ipairs(t) do out[i] = f(v, i) end
  return out
end

function F.filter(t, p)
  local out = {}
  for _, v in ipairs(t) do if p(v) then out[#out+1] = v end end
  return out
end

function F.reduce(t, f, acc)
  local a = acc
  for i, v in ipairs(t) do a = f(a, v, i) end
  return a
end

return F