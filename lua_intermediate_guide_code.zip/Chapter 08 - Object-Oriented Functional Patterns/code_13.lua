local function lens(path) -- path = {"user", "profile", "name"}
  local function get(t)
    local cur = t
    for _, k in ipairs(path) do
      if type(cur) ~= "table" then return nil end
      cur = cur[k]
    end
    return cur
  end

  local function set(t, value)
    local function copy(o)
      if type(o) ~= "table" then return o end
      local r = {}
      for k,v in pairs(o) do r[k] = copy(v) end
      return r
    end
    local root = copy(t)
    local cur = root
    for i, k in ipairs(path) do
      if i == #path then
        cur[k] = value
      else
        cur[k] = type(cur[k]) == "table" and copy(cur[k]) or {}
        cur = cur[k]
      end
    end
    return root
  end

  return { get = get, set = set }
end

-- usage
local L = lens({"user","profile","name"})
local state = { user = { profile = { name = "Ada" } } }
local name = L.get(state)                   -- "Ada"
local new_state = L.set(state, "Zara")      -- original unchanged