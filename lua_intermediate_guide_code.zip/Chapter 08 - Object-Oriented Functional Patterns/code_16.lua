function Item.new(id, name, price)
  assert(type(id)=="string" and id~="")
  assert(type(name)=="string" and name~="")
  assert(type(price)=="number" and price>=0)
  return setmetatable({ id=id, name=name, price=price }, Item)
end

return Item