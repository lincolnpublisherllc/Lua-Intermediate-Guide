local F = require("F")
local nums = {3, 10, 5, 8}
local even = F.filter(nums, function(x) return x%2==0 end)
local doubled = F.map(even, function(x) return x*2 end)
local sum = F.reduce(doubled, function(a,b) return a+b end, 0)
-- even = {10, 8}; doubled = {20,16}; sum = 36