-- using 30log (installed via LuaRocks)
local class = require("30log")
local Shape = class("Shape", {x=0, y=0})
function Shape:move(dx,dy) self.x, self.y = self.x+dx, self.y+dy end

local Circle = Shape:extend("Circle", {r=1})
function Circle:area() return math.pi * self.r * self.r end