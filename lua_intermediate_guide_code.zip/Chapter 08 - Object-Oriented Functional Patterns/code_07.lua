local function readonly(t)
  return setmetatable({}, {
    __index = t,
    __newindex = function() error("readonly") end,
    __pairs = function() return pairs(t) end,
    __len = function() return #t end,
  })
end