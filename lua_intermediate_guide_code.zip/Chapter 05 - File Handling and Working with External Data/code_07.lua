local function csv_to_jsonl(csv_path, jsonl_path)
  local rf, err = io.open(csv_path, "r"); assert(rf, err)
  local wf, err2 = io.open(jsonl_path, "w"); assert(wf, err2)
  local header
  for line in rf:lines() do
    if not header then
      header = parse_csv_line(line)
    else
      local cells = parse_csv_line(line)
      local obj = {}
      for i, key in ipairs(header) do obj[key] = cells[i] end
      wf:write(json.encode(obj), "\n")
    end
  end
  rf:close(); wf:close()
end