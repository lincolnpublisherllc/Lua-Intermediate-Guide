local function parse_kv(line)
  -- crude split: first token is ISO time, rest are k=v
  local ts, rest = line:match("^(%S+)%s+(.+)$")
  if not ts then return nil, "bad_line" end
  local t = { ts = ts }
  for k, v in rest:gmatch("(%w+)=([^%s]+)") do
    if k == "status" or k == "dur_ms" then v = tonumber(v) end
    t[k] = v
  end
  return t
end