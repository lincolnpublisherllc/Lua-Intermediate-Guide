  if p:match("%.log$") and a.size > 1024*1024 then
    print("large log:", p, a.size)
  end
end)