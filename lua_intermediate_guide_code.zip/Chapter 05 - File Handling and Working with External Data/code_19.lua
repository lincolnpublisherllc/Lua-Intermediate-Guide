local function run_ingestor(args)
  local log_path     = args.log or "app.log"
  local out_path     = args.out or "metrics.json"
  local flush_everyS = args.flush_s or 10

  local agg = Aggregator.new()
  local last_flush = os.time()

  local function on_line(line)
    local ev = parse_kv(line)
    if ev then agg:add(ev) end
    local now = os.time()
    if now - last_flush >= flush_everyS then
      local data = agg:flush_json()
      write_atomic(out_path, data)
      last_flush = now
    end
  end

  return tail_file(log_path, on_line, 200)
end

-- Example entry:
-- run_ingestor{ log = "logs/app.log", out = "out/metrics.json", flush_s = 5 }