local function load_lua_table(path)
  local ok, t = pcall(dofile, path)
  if not ok then return nil, "bad_config" end
  if type(t) ~= "table" then return nil, "bad_config" end
  return t
end

local function merge(a, b)
  local out = {}
  for k,v in pairs(a or {}) do out[k] = v end
  for k,v in pairs(b or {}) do out[k] = v end
  return out
end

local defaults = { port = 8080, log = "info" }
local filecfg = load_lua_table("config.lua") or {}
local envcfg  = (function()
  local t = {}
  if os.getenv("APP_PORT") then t.port = tonumber(os.getenv("APP_PORT")) end
  if os.getenv("APP_LOG")  then t.log  = os.getenv("APP_LOG") end
  return t
end)()

local cfg = merge(defaults, merge(filecfg, envcfg))