local function parse_csv_line(line, sep)
  sep = sep or ","
  local out, i, inq = {}, 1, false
  local field = {}
  while i <= #line do
    local c = line:sub(i,i)
    if c == '"' then
      if inq and line:sub(i+1,i+1) == '"' then
        field[#field+1] = '"'; i = i + 1
      else
        inq = not inq
      end
    elseif c == sep and not inq then
      out[#out+1] = table.concat(field); field = {}
    else
      field[#field+1] = c
    end
    i = i + 1
  end
  out[#out+1] = table.concat(field)
  return out
end