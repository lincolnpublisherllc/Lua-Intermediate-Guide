local function sum_temps(path)
  local f = assert(io.open(path, "rb"))
  local total, n = 0, 0
  local sz = string.packsize(fmt)
  while true do
    local block = f:read(sz)
    if not block or #block < sz then break end
    local _id, temp = string.unpack(fmt, block)
    total, n = total + temp, n + 1
  end
  f:close()
  return n > 0 and total / n or nil, n
end