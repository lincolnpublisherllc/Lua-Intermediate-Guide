-- Suppose each record: uint32 id, int16 temp, 10-byte string tag, little-endian
local fmt = "<I2 i2 c10"        -- adjust sizes: I2 is 2-byte unsigned; use I4 for 32-bit
-- Note: On some builds, exact sizes vary; check manual or test with packsize.

local function read_records(path)
  local f = assert(io.open(path, "rb"))
  local recs = {}
  while true do
    local block = f:read(string.packsize(fmt))
    if not block or #block < string.packsize(fmt) then break end
    local id, temp, tag = string.unpack(fmt, block)
    tag = tag:gsub("%z+$","")    -- trim NULs
    recs[#recs+1] = {id=id, temp=temp, tag=tag}
  end
  f:close()
  return recs
end