local lfs = require("lfs")

local function tail_file(path, on_line, poll_ms)
  poll_ms = poll_ms or 200
  local f = io.open(path, "r")
  if not f then return nil, "open_failed" end
  f:seek("end", 0)
  local pos = f:seek()

  while true do
    -- try to read a line
    local line = f:read("*l")
    if line then
      on_line(line)
      pos = f:seek()
    else
      -- no new line. detect rotation or truncation
      local stat = lfs.attributes(path)
      if not stat then
        -- path disappeared; wait and retry open
      else
        local cur = stat.size
        if cur < pos then
          -- truncated or rotated; reopen and seek start
          f:close(); f = io.open(path, "r"); if f then pos = 0 end
        end
      end

      -- sleep a bit
      if package.config:sub(1,1) == "\\" then
        os.execute("ping -n 1 -w " .. math.ceil(poll_ms) .. " 127.0.0.1 > NUL")
      else
        os.execute("sleep " .. tostring(poll_ms / 1000))
      end
    end
  end
end