local json = (function()
  local ok, cj = pcall(require, "cjson")
  if ok then return { encode = cj.encode, decode = cj.decode }
  else
    local dj = require("dkjson")
    return { encode = dj.encode, decode = function(s) return dj.decode(s) end }
  end
end)()

-- usage
local t = {name="Ada", scores={90,84,95}}
local s = json.encode(t)
local back = json.decode(s)