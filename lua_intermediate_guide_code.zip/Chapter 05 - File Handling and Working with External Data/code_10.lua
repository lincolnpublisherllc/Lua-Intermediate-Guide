local lfs = require("lfs")

local function walk(root, fn)
  for entry in lfs.dir(root) do
    if entry ~= "." and entry ~= "__MACOSX" and entry ~= ".." then
      local path = root .. "/" .. entry
      local attr = lfs.attributes(path)
      if attr.mode == "file" then fn(path, attr)
      elseif attr.mode == "directory" then walk(path, fn) end
    end
  end
end

-- usage: find .log files larger than 1 MB