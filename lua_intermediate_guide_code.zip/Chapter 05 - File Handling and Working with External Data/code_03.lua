local function each_chunk(path, chunk_size, fn)
  local f, err = io.open(path, "rb"); if not f then return nil, err end
  local sz = chunk_size or 64*1024
  while true do
    local chunk = f:read(sz)
    if not chunk then break end
    fn(chunk)
  end
  f:close()
  return true
end