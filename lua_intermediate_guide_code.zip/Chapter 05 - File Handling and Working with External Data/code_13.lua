local function tmp_path(dir, prefix)
  dir = dir or "."
  prefix = prefix or "tmp"
  local name = string.format("%s/%s_%d_%06d.tmp", dir, prefix, os.time(), math.random(1e6))
  return name
end