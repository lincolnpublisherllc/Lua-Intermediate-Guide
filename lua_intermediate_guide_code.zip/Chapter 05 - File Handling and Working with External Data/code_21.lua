local f = assert(io.open(path,"rb"))
local magic = f:read(4); assert(magic == string.char(0xCA,0xFE,0xBA,0xBE))
-- proceed to unpack fixed records