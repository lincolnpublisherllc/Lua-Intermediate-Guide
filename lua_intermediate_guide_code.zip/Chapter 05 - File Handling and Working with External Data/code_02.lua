local function each_line(path, fn)
  local f, err = io.open(path, "r"); if not f then return nil, err end
  for line in f:lines() do
    fn(line)
  end
  f:close()
  return true
end