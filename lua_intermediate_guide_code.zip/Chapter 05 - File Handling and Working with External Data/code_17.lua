local function minute_bucket(iso)
  -- "YYYY-MM-DDTHH:MM:SSZ" -> "YYYY-MM-DDTHH:MMZ"
  return iso:sub(1,16) .. "Z"
end

function Aggregator.new()
  return setmetatable({ svc = {}, lat = {} }, Aggregator)
end

function Aggregator:add(ev)
  local bucket = minute_bucket(ev.ts or "")
  if not bucket then return end

  -- counts per service+status
  local sv = self.svc[bucket] or {}; self.svc[bucket] = sv
  local key = (ev.service or "unknown") .. "|" .. tostring(ev.status or 0)
  sv[key] = (sv[key] or 0) + 1

  -- latencies by route
  if ev.route and ev.dur_ms then
    local L = self.lat[bucket] or {}; self.lat[bucket] = L
    local list = L[ev.route] or {}; L[ev.route] = list
    list[#list+1] = ev.dur_ms
  end
end

local function percentile(sorted, p)
  if #sorted == 0 then return nil end
  local idx = math.floor((p/100) * (#sorted - 1) + 1 + 0.5)
  if idx < 1 then idx = 1 end
  if idx > #sorted then idx = #sorted end
  return sorted[idx]
end

function Aggregator:flush_json()
  -- compute summaries and return a JSON string
  local out = { svc = self.svc, lat = {} }
  for bucket, routes in pairs(self.lat) do
    out.lat[bucket] = {}
    for route, arr in pairs(routes) do
      table.sort(arr)
      out.lat[bucket][route] = { p50 = percentile(arr, 50), p95 = percentile(arr, 95) }
    end
  end
  -- reset latency arrays after flush, keep counts accumulating or reset depending on policy
  self.lat = {}
  local json = (function()
    local ok, cj = pcall(require, "cjson")
    if ok then return cj else return require("dkjson") end
  end)()
  if json.encode then
    return json.encode(out)
  else
    -- dkjson returns string, pretty disabled for compactness
    return json.encode(out, { indent = false })
  end
end