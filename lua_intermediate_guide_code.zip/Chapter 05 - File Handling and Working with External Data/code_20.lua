local function grep_file(path, pat)
  local f = assert(io.open(path, "rb"))
  local buf = ""; local sz = 64*1024
  while true do
    local chunk = f:read(sz); if not chunk then break end
    buf = buf .. chunk
    for line in buf:gmatch("([^\n]*)\n") do
      if line:find(pat) then print(line) end
    end
    buf = buf:match("([^\n]*)$") or "" -- keep partial tail
  end
  f:close()
  if #buf > 0 and buf:find(pat) then print(buf) end
end