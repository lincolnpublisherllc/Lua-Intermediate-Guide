local function slurp(path)
  local f, err = io.open(path, "rb"); if not f then return nil, err end
  local data = f:read("*a")
  f:close()
  return data
end