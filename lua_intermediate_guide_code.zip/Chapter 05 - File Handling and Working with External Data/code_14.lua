local function write_atomic(path, data)
  local tmp = tmp_path((path:match("^(.*)/") or "."), "atomic")
  local f = assert(io.open(tmp, "wb"))
  f:write(data)
  f:close()
  -- On POSIX, rename is atomic if same filesystem
  os.remove(path)   -- ignore error if it doesn't exist
  assert(os.rename(tmp, path))
end