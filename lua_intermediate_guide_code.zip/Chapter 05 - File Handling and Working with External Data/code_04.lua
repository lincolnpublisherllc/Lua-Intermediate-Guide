local function make_buffered_writer(path, flush_bytes)
  local f, err = io.open(path, "wb"); if not f then return nil, err end
  local buf, n, limit = {}, 0, flush_bytes or 64*1024
  local W = {}

  function W:write(s)
    n = n + #s; buf[#buf+1] = s
    if n >= limit then self:flush() end
  end

  function W:flush()
    if #buf > 0 then f:write(table.concat(buf)); buf, n = {}, 0 end
  end

  function W:close()
    self:flush(); f:close()
  end

  return W
end