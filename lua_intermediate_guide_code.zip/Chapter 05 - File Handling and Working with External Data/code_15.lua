local function write_lines_atomic(path, iter)
  local tmp = tmp_path((path:match("^(.*)/") or "."), "atomic")
  local f = assert(io.open(tmp, "wb"))
  for line in iter do
    f:write(line, "\n")
  end
  f:close()
  os.remove(path); assert(os.rename(tmp, path))
end