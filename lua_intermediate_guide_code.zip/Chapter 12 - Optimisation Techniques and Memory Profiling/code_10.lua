local function make_writer(path, chunk)
  local f = assert(io.open(path, "wb"))
  local buf, n, limit = {}, 0, chunk or 64*1024
  return {
    write = function(s)
      buf[#buf+1] = s; n = n + #s
      if n >= limit then f:write(table.concat(buf)); buf, n = {}, 0 end
    end,
    close = function()
      if n > 0 then f:write(table.concat(buf)) end; f:close()
    end
  }
end

local tmp = {} -- scratch reused by transform if needed
local function process_file_v2(src, dst)
  local rf = assert(io.open(src, "r"))
  local w  = make_writer(dst, 128*1024)
  for line in rf:lines() do
    if #line > 0 then
      local obj = json.decode(line)
      obj = transform_obj(obj, tmp)
      w.write(json.encode(obj)); w.write("\n")
    end
  end
  rf:close(); w.close()
end