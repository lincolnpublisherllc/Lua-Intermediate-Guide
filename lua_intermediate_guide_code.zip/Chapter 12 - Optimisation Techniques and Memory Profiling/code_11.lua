local lower_map = {}
for i=0,255 do
  local c = string.char(i)
  lower_map[c] = string.lower(c)
end

local function tolower_fast(s)
  local out = {}
  for i=1,#s do out[i] = lower_map[s:sub(i,i)] end
  return table.concat(out)
end

local function transform_obj_fast(o)
  o.total_cents = math.floor((o.price or 0) * 100 + 0.5) * (o.qty or 1)
  if o.name then o.name = tolower_fast(o.name) end
  return o
end