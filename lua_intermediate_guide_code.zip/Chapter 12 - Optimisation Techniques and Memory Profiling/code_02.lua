local function mem_kb() return collectgarbage("count") end
local m0 = mem_kb()
-- run workload
local m1 = mem_kb()
print(("mem Δ=%.1f KB"):format(m1 - m0))