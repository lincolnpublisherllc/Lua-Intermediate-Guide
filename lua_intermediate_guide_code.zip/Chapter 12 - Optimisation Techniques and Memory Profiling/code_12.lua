local function process_file_v3(src, dst)
  local rf = assert(io.open(src, "rb"))
  local w  = make_writer(dst, 128*1024)
  local buf = ""
  local CHUNK = 256*1024
  while true do
    local chunk = rf:read(CHUNK)
    if not chunk then break end
    buf = buf .. chunk
    local start = 1
    while true do
      local nl = buf:find("\n", start, true)
      if not nl then
        buf = buf:sub(start) -- keep tail
        break
      end
      local line = buf:sub(start, nl-1)
      if #line > 0 then
        local obj = json.decode(line)
        obj = transform_obj_fast(obj)
        w.write(json.encode(obj)); w.write("\n")
      end
      start = nl + 1
    end
  end
  if #buf > 0 then
    local obj = json.decode(buf); obj = transform_obj_fast(obj)
    w.write(json.encode(obj)); w.write("\n")
  end
  rf:close(); w.close()
end