local function bench(label, f, iters)
  iters = iters or 1
  local t0 = os.clock()
  local res
  for _ = 1, iters do res = f() end
  local dt = os.clock() - t0
  io.stderr:write(string.format("%-20s  %.3f s  (iters=%d)\n", label, dt, iters))
  return res, dt
end