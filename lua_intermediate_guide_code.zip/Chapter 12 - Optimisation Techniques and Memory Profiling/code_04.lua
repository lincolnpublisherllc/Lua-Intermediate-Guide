local buf = {}
for i = 1, 10000 do
  buf[#buf+1] = "row=" .. i .. "\n"
end
local s = table.concat(buf)