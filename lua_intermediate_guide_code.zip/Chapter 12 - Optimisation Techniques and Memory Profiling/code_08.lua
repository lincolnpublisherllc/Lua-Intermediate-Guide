local samples = {}
local function hook()
  local info = debug.getinfo(2, "Sln")
  local key = (info.short_src or "?") .. ":" .. (info.currentline or 0)
  samples[key] = (samples[key] or 0) + 1
end

debug.sethook(hook, "", 10000)  -- sample every 10k VM instructions
-- run workload
debug.sethook()
-- dump top sites