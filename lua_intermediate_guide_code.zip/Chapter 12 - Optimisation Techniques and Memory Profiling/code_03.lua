local n = 10000
local t = table.create and table.create(n, 0) or {}  -- Lua 5.4 may have table.create; fall back if absent
for i = 1, n do t[i] = i end