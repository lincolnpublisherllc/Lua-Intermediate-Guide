local ok, ffi = pcall(require, "ffi")
if ok then
  ffi.cdef "typedef struct { double x; double y; } pair;"
  local arr = ffi.new("pair[?]", 100000)
  for i=0,99999 do arr[i].x, arr[i].y = i, i*2 end
  -- process arr with tight loops
end