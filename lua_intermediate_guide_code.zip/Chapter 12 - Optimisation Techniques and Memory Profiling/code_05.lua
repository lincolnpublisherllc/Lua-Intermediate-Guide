local function sum_numeric_for(t)
  local s = 0
  for i = 1, #t do s = s + t[i] end
  return s
end

local function sum_numeric_ipairs(t)
  local s = 0
  for _, v in ipairs(t) do s = s + v end
  return s
end

local data = {}
for i=1,1e6 do data[i]=1 end