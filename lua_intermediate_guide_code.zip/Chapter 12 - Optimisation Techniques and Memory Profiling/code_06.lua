local pool = {}
local function acquire()
  local t = table.remove(pool)
  if t then return t end
  return {a=false, b=0, c=nil}
end
local function release(t)
  t.a, t.b, t.c = false, 0, nil
  pool[#pool+1] = t
end