local json = (function()
  local ok, cj = pcall(require, "cjson")
  if ok then return cj else return require("dkjson") end
end)()

local function transform_obj(o)
  -- toy transform: compute total_cents and normalize name
  o.total_cents = math.floor((o.price or 0) * 100 + 0.5) * (o.qty or 1)
  if o.name then o.name = string.lower(o.name) end
  return o
end

local function process_file(src, dst)
  local rf = assert(io.open(src, "r"))
  local wf = assert(io.open(dst, "w"))
  for line in rf:lines() do
    if #line > 0 then
      local obj = json.decode(line)
      obj = transform_obj(obj)
      wf:write(json.encode(obj), "\n")
    end
  end
  rf:close(); wf:close()
end