-- app/mathx.lua
local M = {}

local function check_num(x)
  if type(x) ~= "number" then return nil, "number required" end
  return true
end

function M.clamp(x, lo, hi)
  local ok, err = check_num(x); if not ok then return nil, err end
  if x < lo then return lo end
  if x > hi then return hi end
  return x
end

return M