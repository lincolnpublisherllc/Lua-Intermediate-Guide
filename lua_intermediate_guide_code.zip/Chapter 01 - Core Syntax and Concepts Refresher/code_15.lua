  local avg, err = core.average({})
  assert_eq(avg, nil, "avg empty")
  assert_eq(err, "empty", "avg empty reason")
end