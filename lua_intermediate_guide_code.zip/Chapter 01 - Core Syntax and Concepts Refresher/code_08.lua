local function main()
  local a, err = parse_number(arg[1])
  if not a then return nil, "arg1: " .. err end
  -- rest of program...
  return true
end

local function traceback(msg)
  return debug.traceback("Fatal: " .. tostring(msg), 2)
end

local ok, res = xpcall(main, traceback)
if not ok then
  print(res)
  os.exit(1)
end