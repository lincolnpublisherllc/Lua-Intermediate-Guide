local counter = (function()
  local n = 0             -- upvalue, private to returned functions
  return {
    inc = function() n = n + 1; return n end,
    get = function() return n end
  }
end)()

print(counter.inc())       -- 1
print(counter.get())       -- 1