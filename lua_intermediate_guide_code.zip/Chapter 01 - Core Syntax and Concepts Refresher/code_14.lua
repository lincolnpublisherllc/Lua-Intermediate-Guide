-- spec_report.lua
local core   = require("report.core")
local format = require("report.format")

local function assert_eq(a, b, label)
  if a ~= b then
    error((label or "assert_eq") .. ": expected " .. tostring(b) .. " got " .. tostring(a))
  end
end