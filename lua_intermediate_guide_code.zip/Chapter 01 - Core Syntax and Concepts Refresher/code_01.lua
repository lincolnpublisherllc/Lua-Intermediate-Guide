-- good: cache requires in locals at the top of the module
local json = require("cjson")        -- or dkjson
local lfs  = require("lfs")

local M = {}

function M.load_config(path)
  local f, err = io.open(path, "r")
  if not f then return nil, err end
  local text = f:read("*a")
  f:close()
  return json.decode(text)           -- library call stays behind a local
end

return M