-- grade_report.lua (original single-file style)
local name = arg[1]
local s1 = tonumber(arg[2])
local s2 = tonumber(arg[3])
local s3 = tonumber(arg[4])

local avg = (s1 + s2 + s3) / 3
local grade = (avg >= 70 and "A") or (avg >= 60 and "B") or (avg >= 50 and "C") or "D"
print(string.format("%s | Avg: %.2f | Grade: %s", name, avg, grade))