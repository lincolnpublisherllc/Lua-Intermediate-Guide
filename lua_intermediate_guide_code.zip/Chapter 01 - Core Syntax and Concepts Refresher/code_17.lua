local function run_safely(f, ...)
  local function handler(msg)
    return debug.traceback("Error: " .. tostring(msg), 2)
  end
  return xpcall(f, handler, ...)
end