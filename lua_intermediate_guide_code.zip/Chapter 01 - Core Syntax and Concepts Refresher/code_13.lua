-- main.lua
local cli = require("report.cli")

local function top()
  local ok = cli.main(arg)
  if not ok then return error("failed") end
end

local function trace(msg)
  return debug.traceback("Fatal: " .. tostring(msg), 2)
end

local ok, err = xpcall(top, trace)
if not ok then
  print(err)
  os.exit(1)
end