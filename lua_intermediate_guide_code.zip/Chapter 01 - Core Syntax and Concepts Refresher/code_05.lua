-- app/reporter.lua
local M = {}

-- dependency injection: pass in IO and clock so tests can fake them
function M.new(io_like, clock)
  io_like = io_like or io
  clock   = clock   or os

  local R = {}

  function R:line(...)
    io_like.write(table.concat({...}, " "), "\n")
  end

  function R:timestamp()
    return os.date("%Y-%m-%d %H:%M:%S", clock.time())
  end

  function R:info(msg)
    self:line("[", self:timestamp(), "] INFO:", msg)
  end

  return R
end

return M