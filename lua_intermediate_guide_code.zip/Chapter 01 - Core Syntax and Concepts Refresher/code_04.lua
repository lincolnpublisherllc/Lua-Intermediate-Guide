-- main.lua
local mathx = require("app.mathx")
print(mathx.clamp(15, 0, 10))  -- 10