local function parse_number(s)
  local n = tonumber(s)
  if not n then return nil, "not a number" end
  return n
end