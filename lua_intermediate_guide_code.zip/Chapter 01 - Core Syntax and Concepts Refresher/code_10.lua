-- report/core.lua
local M = {}

local function valid_score(s)
  return type(s) == "number" and s >= 0 and s <= 100
end

function M.average(scores)
  if #scores == 0 then return nil, "empty" end
  local sum = 0
  for i = 1, #scores do
    local x = scores[i]
    if not valid_score(x) then
      return nil, "bad_input"
    end
    sum = sum + x
  end
  return sum / #scores
end

function M.letter(avg)
  if type(avg) ~= "number" then return nil, "bad_input" end
  if avg >= 70 then return "A" end
  if avg >= 60 then return "B" end
  if avg >= 50 then return "C" end
  return "D"
end

function M.report(name, scores)
  if type(name) ~= "string" or name == "" then
    return nil, "bad_input"
  end
  local avg, err = M.average(scores)
  if not avg then return nil, err end
  local letter = M.letter(avg)
  return {name = name, avg = avg, grade = letter}
end

return M