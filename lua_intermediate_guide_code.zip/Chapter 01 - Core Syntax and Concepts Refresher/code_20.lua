local core = require("report.core")
for k in pairs(core) do print(k) end
-- Should print: average, letter, report