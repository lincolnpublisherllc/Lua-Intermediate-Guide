  local g, err = require("report.core").letter("x")
  assert(g == nil and err == "bad_input", "letter bad_input")
end