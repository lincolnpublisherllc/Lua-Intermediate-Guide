-- report/cli.lua
local core   = require("report.core")
local format = require("report.format")

local M = {}

local function parse_args(a)
  local name = a[1]
  local s1 = tonumber(a[2])
  local s2 = tonumber(a[3])
  local s3 = tonumber(a[4])
  if not name or not s1 or not s2 or not s3 then
    return nil, "usage: report <name> <s1> <s2> <s3>"
  end
  return name, {s1, s2, s3}
end

function M.main(a)
  local name, scores = parse_args(a)
  if not name then
    print(scores)             -- reuse 'scores' as message here
    return false
  end

  local rec, err = core.report(name, scores)
  if not rec then
    print("Error:", err)
    return false
  end

  print(format.line(rec))
  return true
end

return M