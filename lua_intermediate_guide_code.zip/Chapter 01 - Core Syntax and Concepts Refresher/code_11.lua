-- report/format.lua
local M = {}

function M.line(rec)
  return string.format("%s | Avg: %.2f | Grade: %s", rec.name, rec.avg, rec.grade)
end

return M