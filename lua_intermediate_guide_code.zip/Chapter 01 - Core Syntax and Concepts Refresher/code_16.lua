  local rec, err = core.report("Ada", {90, 84, 95})
  assert_eq(err, nil, "report ok")
  assert_eq(string.format("%.2f", rec.avg), "89.67", "avg value")
  assert_eq(rec.grade, "B", "grade letter")
  assert_eq(format.line(rec), "Ada | Avg: 89.67 | Grade: B", "format")
end

print("spec_report: ok")