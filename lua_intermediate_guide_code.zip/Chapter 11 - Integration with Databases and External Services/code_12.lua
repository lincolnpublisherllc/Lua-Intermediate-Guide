-- content_by_lua_block (nginx.conf)
local cjson = require "cjson.safe"
local Svc = require "service"
local Store = require "store"

local db = Store.open("/var/app/app.db")