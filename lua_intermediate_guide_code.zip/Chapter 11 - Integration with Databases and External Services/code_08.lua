-- store.lua
local sqlite3 = require "lsqlite3"
local json = require "dkjson"

local M = {}

function M.open(path)
  local db = sqlite3.open(path or "app.db")
  db:busy_timeout(5000)
  return db
end

function M.migrate(db) -- (use the migration code from §2)
  -- ... (omitted here to keep it short)
end

function M.create_item(db, name, price_cents, tags)
  local stmt = db:prepare("INSERT INTO items(name,price_cents,tags_json,created_at) VALUES(?,?,?,?)")
  stmt:bind_values(name, price_cents, json.encode(tags or {}), os.date("!%Y-%m-%dT%H:%M:%SZ"))
  assert(stmt:step() == sqlite3.DONE); stmt:finalize()
  return db:last_insert_rowid()
end

function M.get_item(db, id)
  local stmt = db:prepare("SELECT * FROM items WHERE id = ?")
  stmt:bind_values(id)
  local row = stmt:nrows()()
  stmt:finalize()
  if not row then return nil end
  row.tags = json.decode(row.tags_json or "[]"); return row
end

function M.search_items(db, q, limit, cursor_id)
  limit = limit or 20
  if q and #q > 0 then
    -- FTS first; fall back to LIKE if FTS not available in your build
    local stmt = db:prepare("SELECT rowid AS id, name FROM items_fts WHERE items_fts MATCH ? LIMIT ?")
    stmt:bind_values(q, limit)
    local out = {}; for row in stmt:nrows() do out[#out+1] = row end
    stmt:finalize(); return out
  else
    if cursor_id then
      local stmt = db:prepare("SELECT id,name,price_cents,created_at FROM items WHERE id < ? ORDER BY id DESC LIMIT ?")
      stmt:bind_values(cursor_id, limit)
      local out = {}; for r in stmt:nrows() do out[#out+1] = r end
      stmt:finalize(); return out
    else
      local stmt = db:prepare("SELECT id,name,price_cents,created_at FROM items ORDER BY id DESC LIMIT ?")
      stmt:bind_values(limit)
      local out = {}; for r in stmt:nrows() do out[#out+1] = r end
      stmt:finalize(); return out
    end
  end
end

return M