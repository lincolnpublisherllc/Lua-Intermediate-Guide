local svc = Svc.new(db)

local uri = ngx.var.uri
local args = ngx.req.get_uri_args()

if ngx.req.get_method() == "GET" and uri == "/items" then
  local cursor = tonumber(args.cursor)
  local out = svc:list({ limit = tonumber(args.limit) or 20, cursor_id = cursor })
  ngx.header.content_type = "application/json"; ngx.say(cjson.encode(out)); return
end

if ngx.req.get_method() == "GET" and uri == "/items/search" then
  local out = svc:search(args.q or "", tonumber(args.limit) or 20)
  ngx.header.content_type = "application/json"; ngx.say(cjson.encode(out)); return
end

if ngx.req.get_method() == "POST" and uri == "/items" then
  ngx.req.read_body()
  local body = cjson.decode(ngx.req.get_body_data() or "{}") or {}
  if type(body.name) ~= "string" or type(body.price_cents) ~= "number" then
    ngx.status = 400; ngx.say('{"error":"bad_input"}'); return
  end
  local id = svc:create_item(body.name, body.price_cents, body.tags or {})
  ngx.header.content_type = "application/json"; ngx.say(cjson.encode({ id = id })); return
end