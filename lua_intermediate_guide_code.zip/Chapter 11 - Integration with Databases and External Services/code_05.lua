local function search_items(db, term, limit)
  term = term or ""; limit = limit or 20
  local q = db:prepare("SELECT rowid AS id, name FROM items_fts WHERE items_fts MATCH ? LIMIT ?")
  q:bind_values(term, limit)
  local out = {}; for row in q:nrows() do table.insert(out, row) end
  q:finalize(); return out
end