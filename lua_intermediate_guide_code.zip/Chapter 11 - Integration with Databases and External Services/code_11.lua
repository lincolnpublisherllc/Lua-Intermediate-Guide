function Svc.new(db) -- db is a live sqlite handle
  local self = setmetatable({ db = db }, Svc)
  self.cached_get = Cache.memoize1(function(id) return Store.get_item(db, id) end)
  return self
end

function Svc:create_item(name, price_cents, tags)
  return Store.create_item(self.db, name, price_cents, tags)
end

function Svc:get_item(id)
  return self.cached_get(tonumber(id))
end

function Svc:list(opts)
  return Store.search_items(self.db, nil, opts and opts.limit or 20, opts and opts.cursor_id)
end

function Svc:search(q, limit)
  return Store.search_items(self.db, q, limit or 20)
end

return Svc