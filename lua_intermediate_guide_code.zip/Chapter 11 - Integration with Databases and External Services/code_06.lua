local function memoize(fn)
  local cache = setmetatable({}, { __mode = "v" })
  return function(key)
    local e = cache[key]
    if e ~= nil then return e end
    local v = fn(key)
    cache[key] = v
    return v
  end
end

-- Example: cache get_item by id for a short-lived process
local function make_item_cache(db)
  local function fetch(id) return get_item(db, id) end
  return memoize(fetch)
end