-- cache.lua
local function memoize1(fn)
  local cache = setmetatable({}, { __mode = "v" })
  return function(k)
    local v = cache[k]
    if v ~= nil then return v end
    v = fn(k); cache[k] = v; return v
  end
end

return { memoize1 = memoize1 }