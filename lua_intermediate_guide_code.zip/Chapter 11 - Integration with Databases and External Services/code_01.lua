local sqlite3 = require "lsqlite3"
local DB = {}

function DB.open(path)
  local db = sqlite3.open(path or "app.db")
  db:busy_timeout(5000) -- wait up to 5s for locks
  return db
end