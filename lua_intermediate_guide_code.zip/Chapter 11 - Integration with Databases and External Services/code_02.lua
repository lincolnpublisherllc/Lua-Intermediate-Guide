local function exec_assert(db, sql)
  local rc = db:exec(sql)
  assert(rc == sqlite3.OK, db:errmsg())
end

local function ensure_migrations_table(db)
  exec_assert(db, [[
    CREATE TABLE IF NOT EXISTS schema_migrations(
      version INTEGER PRIMARY KEY
    );
  ]])
end

local function applied_versions(db)
  local t = {}
  for row in db:nrows("SELECT version FROM schema_migrations") do
    t[row.version] = true
  end
  return t
end

local migrations = {
  [1] = [[
    CREATE TABLE items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price_cents INTEGER NOT NULL,
      tags_json TEXT DEFAULT '[]',
      created_at TEXT NOT NULL
    );
    CREATE INDEX idx_items_name ON items(name);
  ]],
  [2] = [[
    CREATE VIRTUAL TABLE items_fts USING fts5(name, content='items', content_rowid='id');
    INSERT INTO items_fts(rowid, name) SELECT id, name FROM items;
    CREATE TRIGGER items_ai AFTER INSERT ON items BEGIN
      INSERT INTO items_fts(rowid, name) VALUES (new.id, new.name);
    END;
    CREATE TRIGGER items_au AFTER UPDATE ON items BEGIN
      UPDATE items_fts SET name=new.name WHERE rowid=new.id;
    END;
    CREATE TRIGGER items_ad AFTER DELETE ON items BEGIN
      INSERT INTO items_fts(items_fts, rowid, name) VALUES('delete', old.id, old.name);
    END;
  ]],