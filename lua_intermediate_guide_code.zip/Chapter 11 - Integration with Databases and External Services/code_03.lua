function DB.migrate(db)
  ensure_migrations_table(db)
  local done = applied_versions(db)
  for v, sql in pairs(migrations) do
    if not done[v] then
      exec_assert(db, "BEGIN")
      local ok, err = pcall(exec_assert, db, sql)
      if ok then
        exec_assert(db, "INSERT INTO schema_migrations(version) VALUES("..v..")")
        exec_assert(db, "COMMIT")
      else
        exec_assert(db, "ROLLBACK")
        error("migration "..v.." failed: "..tostring(err))
      end
    end
  end
end