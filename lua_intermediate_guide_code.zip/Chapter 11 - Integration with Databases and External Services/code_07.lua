local http = require "socket.http"
local ltn12 = require "ltn12"

local function http_request(opts)
  local resp = {}
  local ok, code = http.request{
    url = opts.url,
    method = opts.method or "GET",
    headers = opts.headers,
    source  = opts.source,              -- optional LTN12 source for body
    sink    = ltn12.sink.table(resp),
    redirect = true,
  }
  return ok and code, table.concat(resp)
end

local function sleep_s(seconds)
  if package.config:sub(1,1) == "\\" then
    os.execute("ping -n 1 -w "..math.ceil(seconds*1000).." 127.0.0.1 > NUL")
  else
    os.execute("sleep "..tostring(seconds))
  end
end

local function with_retries(do_call, is_retryable, max_tries)
  max_tries = max_tries or 5
  local base = 0.2
  for i=1,max_tries do
    local code, body = do_call()
    if not is_retryable(code, body, i) then return code, body end
    local jitter = math.random() * 0.1
    local backoff = math.min(2.0, base * (2^(i-1))) + jitter
    sleep_s(backoff)
  end
  return nil, "retry_exhausted"
end

-- Example: POST with idempotency key
local function post_json(url, json_body, idem_key)
  local src = ltn12.source.string(json_body)
  local headers = {
    ["content-type"] = "application/json",
    ["content-length"] = tostring(#json_body),
    ["Idempotency-Key"] = idem_key or tostring(os.time()).."-"..math.random(1e6),
  }
  local function call()
    return http_request{ url=url, method="POST", headers=headers, source=src }
  end
  local function retryable(code, _body, try)
    return (code == 429 or (type(code)=="number" and code >= 500))
  end
  return with_retries(call, retryable, 5)
end